import React, { useState, useCallback, useEffect, useMemo, useRef } from 'react';
import { HomePage } from './pages/HomePage';
import { PostAdPage } from './pages/PostAdPage';
import { AdDetailPage } from './pages/AdDetailPage';
import { ProfilePage } from './pages/ProfilePage';
import { ChatListPage } from './pages/ChatListPage';
import { ChatDetailPage } from './pages/ChatDetailPage';
import { NotificationsPage } from './pages/NotificationsPage';
import { AdsExplorerPage } from './pages/AdsExplorerPage';
import { AdminPage } from './pages/AdminPage';
import { AuthPage } from './pages/AuthPage';
import { MaintenancePage } from './pages/MaintenancePage';
import { MarketAdvisorPage } from './pages/MarketAdvisorPage';
import { AuctionsListPage } from './pages/AuctionsListPage';
import { AuctionDetailPage } from './pages/AuctionDetailPage';
import { NotFoundPage } from './pages/NotFoundPage';
import { BottomNav } from './components/BottomNav';
import { AIAssistant } from './components/AIAssistant';
import { AIAssistantMode, Review, User, Toast, ToastType, UserRole, Ad, AdminSection } from './types';
import { UserProvider, useUser } from './contexts/UserContext';
import { ChatProvider, useChat } from './contexts/ChatContext';
import { AdminProvider, useAdmin } from './contexts/AdminContext';
import { SparklesIcon } from './components/icons/SparklesIcon';
import { LeaveReviewModal } from './components/LeaveReviewModal';
import { AnnouncementBanner } from './components/AnnouncementBanner';
import { AccountPage } from './pages/AccountPage';
import { ToastContainer } from './components/ToastContainer';
import { AdOptimizerModal } from './components/modals/AdOptimizerModal';
import { CreateFlashDealModal } from './components/modals/CreateFlashDealModal';
import { CreateStockWatchModal } from './components/modals/CreateStockWatchModal';
import { FullScreenLoader } from './components/common/FullScreenLoader';
import { RFQListPage } from './pages/RFQListPage';
import { PostRFQPage } from './pages/PostRFQPage';
import { DailyBriefPage } from './pages/DailyBriefPage';
import { ImpersonationBanner } from './components/ImpersonationBanner';
import { MarketAnalystPage } from './pages/MarketAnalystPage';
import { OpportunitiesHubPage } from './pages/OpportunitiesHubPage';
import { SafePayPage } from './pages/SafePayPage';
import { NegotiationPage } from './pages/NegotiationPage';
import { PermissionWelcomeModal } from './components/modals/PermissionWelcomeModal';
import { FeatureAdModal } from './components/modals/FeatureAdModal';
import { ReferralsPage } from './pages/ReferralsPage';
import { SocialSupportPage } from './pages/SocialSupportPage';
import { InstallPWA } from './components/InstallPWA';
import { ThemeProvider } from './contexts/ThemeContext';

const AppContent: React.FC = () => {
    // --- HOOKS ---
    const [location, setLocation] = useState(window.location.hash || '#/');
    const [isAIOpen, setIsAIOpen] = useState(false);
    const [aiMode, setAIMode] = useState<AIAssistantMode>(AIAssistantMode.NONE);
    const [generatedAdContent, setGeneratedAdContent] = useState({ title: '', description: '' });
    const [isReviewModalOpen, setReviewModalOpen] = useState(false);
    const [reviewModalData, setReviewModalData] = useState<{ adId: string; sellerId: string } | null>(null);
    const [postLoginPath, setPostLoginPath] = useState<string>('/');
    const [toasts, setToasts] = useState<Toast[]>([]);
    const [optimizerModalAd, setOptimizerModalAd] = useState<Ad | null>(null);
    const [flashDealModalAd, setFlashDealModalAd] = useState<Ad | null>(null);
    const [isStockWatchModalOpen, setStockWatchModalOpen] = useState(false);
    const [showPermissionWelcome, setShowPermissionWelcome] = useState(false);
    const [featureModalAd, setFeatureModalAd] = useState<Ad | null>(null);
    
    // Page Transition State
    const [pageKey, setPageKey] = useState(location);
    const [animationClass, setAnimationClass] = useState('animate-page-enter');

    // PWA Install Prompt State
    const [installPromptEvent, setInstallPromptEvent] = useState<any>(null);
    const [showInstallBanner, setShowInstallBanner] = useState(false);

    // Swipe back gesture state
    const pageContainerRef = useRef<HTMLDivElement>(null);
    const touchStartX = useRef(0);
    const isSwiping = useRef(false);

    const { currentUser, logout, isInitialized, impersonatingAdminId, setCurrentUser, impersonate } = useUser();
    const { settings, addReview, users, createFlashDeal, createStockWatch, isDataLoaded, createNotification, updateUser, addUser, unreadNotificationCount } = useAdmin();
    const { unreadCount: unreadChatCount } = useChat();

    useEffect(() => {
        const welcomeSeen = localStorage.getItem('permission_welcome_seen');
        if (!welcomeSeen && 'permissions' in navigator) {
            navigator.permissions.query({ name: 'microphone' as PermissionName }).then(status => {
                if (status.state === 'prompt') {
                    setShowPermissionWelcome(true);
                } else {
                    localStorage.setItem('permission_welcome_seen', 'true');
                }
            }).catch(() => {
                localStorage.setItem('permission_welcome_seen', 'true');
            });
        }
    }, []);
    
    // PWA Install Prompt Handler
    useEffect(() => {
        const handleBeforeInstallPrompt = (e: Event) => {
            e.preventDefault();
            setInstallPromptEvent(e);
            const installBannerDismissed = sessionStorage.getItem('install_banner_dismissed');
            if (!installBannerDismissed) {
                setShowInstallBanner(true);
            }
        };
        window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
        return () => window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    }, []);

    // Badging API Effect
    useEffect(() => {
        if (!currentUser) {
            if ('clearAppBadge' in navigator) {
                // @ts-ignore
                navigator.clearAppBadge().catch((error: any) => console.error("Error clearing app badge:", error));
            }
            return;
        }

        const totalUnread = unreadChatCount + unreadNotificationCount(currentUser.id);
        
        if ('setAppBadge' in navigator) {
            if (totalUnread > 0) {
                // @ts-ignore
                navigator.setAppBadge(totalUnread).catch((error: any) => console.error("Error setting app badge:", error));
            } else {
                // @ts-ignore
                navigator.clearAppBadge().catch((error: any) => console.error("Error clearing app badge:", error));
            }
        }
    }, [currentUser, unreadChatCount, unreadNotificationCount]);

    // Sync currentUser from UserContext to the main users list in AdminContext for persistence
    useEffect(() => {
        if (currentUser) {
            const globalUser = users.find(u => u.id === currentUser.id);
            if (globalUser && JSON.stringify(globalUser) !== JSON.stringify(currentUser)) {
                updateUser(currentUser.id, currentUser);
            }
        }
    }, [currentUser, users, updateUser]);


    const handleNavigation = useCallback((path: string, adminSection?: AdminSection) => {
        let newHash = path;
        if (adminSection) {
            newHash += `?section=${adminSection}`;
        }
        if (`#${newHash}` !== window.location.hash) {
            window.location.hash = newHash;
        }
    }, []);
    
     const addToast = useCallback((message: string, type: ToastType = 'success') => {
        const id = Date.now().toString();
        setToasts(prev => [...prev, { id, message, type }]);
    }, []);

    useEffect(() => {
        const handleHashChange = () => {
            setLocation(window.location.hash || '#/');
        };
        window.addEventListener('hashchange', handleHashChange);
        return () => window.removeEventListener('hashchange', handleHashChange);
    }, []);
    
     // Page Transition Effect
    useEffect(() => {
        if (pageKey === location) return; // Avoid animation on initial load
        setAnimationClass('animate-page-exit');
        const timeoutId = setTimeout(() => {
            setPageKey(location);
            setAnimationClass('animate-page-enter');
        }, 300); // Must match CSS animation duration
        return () => clearTimeout(timeoutId);
    }, [location]);

    // Swipe-to-go-back gesture handler
    useEffect(() => {
        const container = pageContainerRef.current;
        if (!container) return;
    
        const handleTouchStart = (e: TouchEvent) => {
            const path = window.location.hash.substring(1).split('?')[0] || '/';
            if (path === '/' || path === '/auth') { // Don't swipe on home or auth page
                isSwiping.current = false;
                return;
            }
            if (e.touches[0].clientX < 50) { // Start swipe near the edge
                touchStartX.current = e.touches[0].clientX;
            } else {
                touchStartX.current = 0;
            }
        };
    
        const handleTouchMove = (e: TouchEvent) => {
            if (touchStartX.current === 0) return;
    
            const touchCurrentX = e.touches[0].clientX;
            const deltaX = touchCurrentX - touchStartX.current;
    
            if (deltaX > 10 && !isSwiping.current) {
                isSwiping.current = true;
                container.classList.add('swiping');
            }
    
            if (isSwiping.current) {
                const swipeAmount = Math.max(0, deltaX);
                container.style.transform = `translateX(${swipeAmount}px)`;
            }
        };
    
        const handleTouchEnd = (e: TouchEvent) => {
            if (!isSwiping.current) return;
    
            const touchEndX = e.changedTouches[0].clientX;
            const deltaX = touchEndX - touchStartX.current;
    
            container.classList.remove('swiping');
    
            if (deltaX > window.innerWidth / 3) { // Threshold to navigate back
                window.history.back();
            }
            
            // Reset style after transition
            setTimeout(() => {
              if (container) {
                container.style.transform = '';
              }
            }, 300);
            
            isSwiping.current = false;
            touchStartX.current = 0;
        };
    
        container.addEventListener('touchstart', handleTouchStart);
        container.addEventListener('touchmove', handleTouchMove);
        container.addEventListener('touchend', handleTouchEnd);
    
        return () => {
            container.removeEventListener('touchstart', handleTouchStart);
            container.removeEventListener('touchmove', handleTouchMove);
            container.removeEventListener('touchend', handleTouchEnd);
        };
    }, [pageKey]); // Re-attach listeners if the page component changes

    const handleOpenOptimizer = useCallback((ad: Ad) => setOptimizerModalAd(ad), []);
    const handleCloseOptimizer = useCallback(() => setOptimizerModalAd(null), []);
    
    const handleOpenFlashDeal = useCallback((ad: Ad) => setFlashDealModalAd(ad), []);
    const handleCloseFlashDeal = useCallback(() => setFlashDealModalAd(null), []);

    const handleOpenStockWatch = useCallback(() => setStockWatchModalOpen(true), []);
    const handleCloseStockWatch = useCallback(() => setStockWatchModalOpen(false), []);

    const handleOpenFeatureModal = useCallback((ad: Ad) => setFeatureModalAd(ad), []);
    const handleCloseFeatureModal = useCallback(() => setFeatureModalAd(null), []);


    const handleLogout = useCallback(() => {
        logout();
        handleNavigation('/');
    }, [logout, handleNavigation]);

    const handleStopImpersonating = () => {
        const adminId = localStorage.getItem('impersonatingAdminId');
        if(adminId){
            const adminUser = users.find(u => u.id === adminId);
            if(adminUser){
                setCurrentUser(adminUser);
                localStorage.removeItem('impersonatingAdminId');
                addToast(`عدت إلى حساب المدير ${adminUser.name}`, 'success');
                handleNavigation('/admin');
            }
        }
    }

    const handleImpersonate = (userId: string) => {
        const userToImpersonate = users.find(u => u.id === userId);
        if(userToImpersonate) {
            impersonate(userId);
            setCurrentUser(userToImpersonate);
            handleNavigation('/');
        }
    };
    
    useEffect(() => {
        if (!isInitialized || !isDataLoaded) return;

        const path = location.substring(1).split('?')[0] || '/';
        const protectedRoutes = ['/post', '/chat', '/profile', '/notifications', '/account', '/advisor', '/analyst', '/auctions', '/post-rfq', '/briefing', '/opportunities-hub', '/safepay', '/negotiation', '/referrals', '/social-support'];
        const isAdminRoute = path.startsWith('/admin');
        const adminRoles: UserRole[] = ['admin', 'moderator', 'support'];
        
        const isProtectedRoute = (p: string) => protectedRoutes.some(route => p.startsWith(route));

        if (isProtectedRoute(path) && !currentUser) {
            setPostLoginPath(path);
            handleNavigation('/auth');
            return;
        }
        
        if (isAdminRoute && !currentUser && !impersonatingAdminId) {
            setPostLoginPath(path);
            handleNavigation('/auth');
            return;
        }

        if (currentUser) {
            if (isAdminRoute && !adminRoles.includes(currentUser.role) && !impersonatingAdminId) {
                addToast('ليس لديك الصلاحية للوصول إلى لوحة التحكم.', 'error');
                handleNavigation('/');
                return;
            }
            if ((path.startsWith('/advisor') || path.startsWith('/briefing') || path.startsWith('/analyst')) && currentUser.role !== 'wholesaler' && currentUser.role !== 'admin') {
                addToast('هذه الميزة متاحة للتجار فقط.', 'error');
                handleNavigation('/account');
                return;
            }
             if (path.startsWith('/post-rfq') && currentUser.role !== 'retailer' && currentUser.role !== 'admin') {
                addToast('هذه الميزة متاحة لأصحاب المحلات فقط.', 'error');
                handleNavigation('/account');
                return;
            }
             if (path.startsWith('/opportunities-hub') && !['wholesaler', 'retailer', 'admin'].includes(currentUser.role)) {
                addToast('هذه الميزة متاحة للتجار وأصحاب المحلات فقط.', 'error');
                handleNavigation('/account');
                return;
            }
        }

    }, [location, currentUser, isInitialized, isDataLoaded, handleNavigation, addToast, impersonatingAdminId]);
    
    const openAIAssistant = useCallback((mode: AIAssistantMode) => {
        setAIMode(mode);
        setIsAIOpen(true);
    }, []);

    const closeAIAssistant = useCallback(() => {
        setIsAIOpen(false);
        setAIMode(AIAssistantMode.NONE);
    }, []);
    
    const handleAdGenerated = useCallback((content: { title: string, description: string }) => {
        setGeneratedAdContent(content);
        handleNavigation('/post');
    }, [handleNavigation]);
    
    const handleSearchParsed = useCallback((filters: any) => {
        console.log("AI Search Parsed:", filters);
        handleNavigation('/ads'); 
    }, [handleNavigation]);

    const handleOpenReviewModal = useCallback((adId: string, sellerId: string) => {
        setReviewModalData({ adId, sellerId });
        setReviewModalOpen(true);
    }, []);

    const handleCloseReviewModal = useCallback(() => {
        setReviewModalData(null);
        setReviewModalOpen(false);
    }, []);

    const handleReviewSubmit = useCallback((rating: number, comment: string) => {
        if (reviewModalData && currentUser) {
            addReview({ ...reviewModalData, reviewerId: currentUser.id, rating, comment });
            addToast("شكراً لك! تم إرسال تقييمك بنجاح.", "success");
        }
        handleCloseReviewModal();
    }, [reviewModalData, handleCloseReviewModal, addReview, addToast, currentUser]);
    
    const handleInstallPrompt = () => {
        if (installPromptEvent) {
            installPromptEvent.prompt();
            installPromptEvent.userChoice.then((choiceResult: { outcome: string }) => {
                if (choiceResult.outcome === 'accepted') {
                    addToast('تم تثبيت التطبيق بنجاح!', 'success');
                }
                setInstallPromptEvent(null);
                setShowInstallBanner(false);
            });
        }
    };

    const handleDismissInstallBanner = () => {
        setShowInstallBanner(false);
        sessionStorage.setItem('install_banner_dismissed', 'true');
    };

    if (!isInitialized || !isDataLoaded) {
        return <FullScreenLoader />;
    }

    if (settings.maintenanceMode && !['admin', 'moderator', 'support'].includes(currentUser?.role || '') && !impersonatingAdminId) {
        return <MaintenancePage />;
    }

    const handleLoginSuccess = (user: User) => {
        addToast(`أهلاً بعودتك، ${user.name.split(' ')[0]}!`, 'success');
        if (['admin', 'moderator', 'support'].includes(user.role)) {
            handleNavigation('/admin');
        } else {
            handleNavigation(postLoginPath && postLoginPath !== '/auth' ? postLoginPath : '/');
        }
    };

    const handleRegisterSuccess = (user: User) => {
        addToast(`أهلاً بك ${user.name.split(' ')[0]}! تم إنشاء حسابك بنجاح.`, 'success');
        createNotification({
            userId: user.id,
            type: 'welcome',
            text: 'أهلاً بك في سوق العراق الذكي! نتمنى لك تجربة ممتعة.',
            link: '/account'
        });
        handleNavigation('/');
    };

    const urlParams = new URLSearchParams(location.substring(1).split('?')[1]);
    const referrerId = urlParams.get('ref') || undefined;

    const renderPage = () => {
        const path = location.substring(1).split('?')[0] || '/';
        const matchedRouteKey = Object.keys(routes).find(routeKey => path.startsWith(routeKey)) || '/notfound';
        const PageComponent = routes[matchedRouteKey];
        return PageComponent ? <PageComponent /> : <NotFoundPage onNavigate={handleNavigation} />;
    };
    
    const routes: { [key: string]: React.FC } = {
        '/auth': () => <AuthPage onLoginSuccess={handleLoginSuccess} onRegisterSuccess={handleRegisterSuccess} onNavigate={handleNavigation} referrerId={referrerId} />,
        '/admin': () => <AdminPage onNavigate={handleNavigation} onLogout={handleLogout} />,
        '/account': () => <AccountPage onNavigate={handleNavigation} onLogout={handleLogout} />,
        '/referrals': () => <ReferralsPage onNavigate={handleNavigation} addToast={addToast} />,
        '/advisor': () => <MarketAdvisorPage onNavigate={handleNavigation} />,
        '/analyst': () => <MarketAnalystPage onNavigate={handleNavigation} />,
        '/opportunities-hub': () => <OpportunitiesHubPage onNavigate={handleNavigation} />,
        '/briefing': () => <DailyBriefPage onNavigate={handleNavigation} />,
        '/ads': () => <AdsExplorerPage onNavigate={handleNavigation} onOpenStockWatch={handleOpenStockWatch} />,
        '/rfqs': () => <RFQListPage onNavigate={handleNavigation} addToast={addToast} />,
        '/post-rfq': () => <PostRFQPage onNavigate={handleNavigation} addToast={addToast} />,
        '/social-support': () => <SocialSupportPage onNavigate={handleNavigation} />,
        '/ad/': () => {
            const adId = location.substring(1).split('/')[2];
            return <AdDetailPage adId={adId} onNavigate={handleNavigation} onOpenReviewModal={handleOpenReviewModal} addToast={addToast} />;
        },
        '/post/edit/': () => {
            const adIdToEdit = location.substring(1).split('/')[3];
            return <PostAdPage onNavigate={handleNavigation} onOpenAI={openAIAssistant} onAdGenerated={handleAdGenerated} adContent={generatedAdContent} adIdToEdit={adIdToEdit} addToast={addToast} onOpenFeatureModal={handleOpenFeatureModal}/>;
        },
        '/post': () => <PostAdPage onNavigate={handleNavigation} onOpenAI={openAIAssistant} onAdGenerated={handleAdGenerated} adContent={generatedAdContent} addToast={addToast} onOpenFeatureModal={handleOpenFeatureModal}/>,
        '/profile/': () => {
            const userId = location.substring(1).split('/')[2];
            return <ProfilePage onNavigate={handleNavigation} userId={userId} addToast={addToast} onOpenOptimizer={handleOpenOptimizer} onOpenFlashDeal={handleOpenFlashDeal} onOpenFeatureModal={handleOpenFeatureModal} />;
        },
        '/chat/': () => {
            const conversationId = location.substring(1).split('/')[2];
            return <ChatDetailPage conversationId={conversationId} onNavigate={handleNavigation} addToast={addToast} />;
        },
        '/chat': () => <ChatListPage onNavigate={handleNavigation} />,
        '/notifications': () => <NotificationsPage onNavigate={handleNavigation} />,
        '/auction/': () => {
            const auctionId = location.substring(1).split('/')[2];
            return <AuctionDetailPage auctionId={auctionId} onNavigate={handleNavigation} addToast={addToast} />;
        },
        '/auctions': () => <AuctionsListPage onNavigate={handleNavigation} />,
        '/safepay/': () => {
            const memoId = location.substring(1).split('/')[2];
            return <SafePayPage memoId={memoId} onNavigate={handleNavigation} addToast={addToast} />;
        },
        '/negotiation/': () => {
            const adId = location.substring(1).split('/')[2];
            return <NegotiationPage adId={adId} onNavigate={handleNavigation} addToast={addToast} />;
        },
        '/': () => <HomePage onNavigate={handleNavigation} />,
        '/notfound': () => <NotFoundPage onNavigate={handleNavigation} />
    };
    
    const path = location.substring(1).split('?')[0];
    const adminRoles: UserRole[] = ['admin', 'moderator', 'support'];
    const isSpecialPage = path.startsWith('/chat/') 
        || (path.startsWith('/admin') && currentUser && adminRoles.includes(currentUser.role) && !impersonatingAdminId) 
        || path.startsWith('/post') 
        || path.startsWith('/auth') 
        || path.startsWith('/account') 
        || path.startsWith('/advisor')
        || path.startsWith('/briefing')
        || path.startsWith('/analyst')
        || path.startsWith('/opportunities-hub')
        || path.startsWith('/post-rfq')
        || path.startsWith('/auction/')
        || path.startsWith('/safepay/')
        || path.startsWith('/negotiation/')
        || path.startsWith('/referrals')
        || path.startsWith('/social-support');
    const showBottomNav = !isSpecialPage;
    
    const showAIFab = currentUser && !isSpecialPage;
    
    const sellerForReview = users.find(u => u.id === reviewModalData?.sellerId);
    const adminUser = impersonatingAdminId ? users.find(u => u.id === impersonatingAdminId) : null;

    return (
        <div className="font-tajawal">
            {showPermissionWelcome && <PermissionWelcomeModal onClose={() => {
                localStorage.setItem('permission_welcome_seen', 'true');
                setShowPermissionWelcome(false);
            }} />}
            <ToastContainer toasts={toasts} setToasts={setToasts} />
            {impersonatingAdminId && adminUser && <ImpersonationBanner adminName={adminUser.name} onStop={handleStopImpersonating} />}
            {settings.isAnnouncementActive && <AnnouncementBanner text={settings.announcementText} type={settings.announcementType} />}
            
            <div ref={pageContainerRef} className={`relative page-container ${impersonatingAdminId ? 'pt-12' : ''}`}>
                <div key={pageKey} className={animationClass}>
                    {renderPage()}
                </div>
            </div>
            
            {showBottomNav && (
                <BottomNav onNavigate={handleNavigation} activePath={path || '/'} />
            )}
            
            {showAIFab && (
                 <button
                    onClick={() => openAIAssistant(AIAssistantMode.SEARCH)}
                    className="fixed bottom-20 md:bottom-8 left-5 z-50 bg-brand-accent text-brand-primary p-4 rounded-full shadow-lg shadow-brand-accent/40 hover:bg-brand-accent-hover hover:scale-105 active:scale-95 transition-all duration-300 transform"
                    aria-label="مساعد البحث الذكي"
                    title="مساعد البحث الذكي"
                >
                    <SparklesIcon className="h-7 w-7" />
                </button>
            )}

            <AIAssistant
                isOpen={isAIOpen}
                onClose={closeAIAssistant}
                mode={aiMode}
                onAdGenerated={handleAdGenerated}
                onSearchParsed={handleSearchParsed}
            />

            <LeaveReviewModal
                isOpen={isReviewModalOpen}
                onClose={handleCloseReviewModal}
                onSubmit={handleReviewSubmit}
                sellerName={sellerForReview?.name || ''}
            />

            <AdOptimizerModal
                ad={optimizerModalAd}
                onClose={handleCloseOptimizer}
            />
            <CreateFlashDealModal
                ad={flashDealModalAd}
                onClose={handleCloseFlashDeal}
                onSubmit={(adId, dealPrice, durationHours) => {
                    createFlashDeal(adId, dealPrice, durationHours);
                    addToast('تم إنشاء صفقة البرق بنجاح!', 'success');
                    handleCloseFlashDeal();
                }}
            />
             <CreateStockWatchModal
                isOpen={isStockWatchModalOpen}
                onClose={handleCloseStockWatch}
                onSubmit={(watchData) => {
                    if (currentUser) {
                        createStockWatch(watchData, currentUser.id);
                        addToast('تم إنشاء رادار السوق بنجاح!', 'success');
                        handleCloseStockWatch();
                    } else {
                        addToast('يجب تسجيل الدخول أولاً', 'error');
                    }
                }}
            />
            <FeatureAdModal
                ad={featureModalAd}
                onClose={handleCloseFeatureModal}
                addToast={addToast}
            />
            {showInstallBanner && installPromptEvent && (
                <InstallPWA
                    onInstall={handleInstallPrompt}
                    onDismiss={handleDismissInstallBanner}
                />
            )}
        </div>
    );
}

const App: React.FC = () => {
    return (
        <ThemeProvider>
            <AdminProvider>
            <UserProvider>
                <ChatProvider>
                    <AppContent />
                </ChatProvider>
                </UserProvider>
            </AdminProvider>
        </ThemeProvider>
    );
};

export default App;