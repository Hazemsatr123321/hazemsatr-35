

// NEW Interfaces for nested object types
export interface PriceTier {
  quantity: number;
  price: string;
}

export interface FlashDeal {
  isActive: boolean;
  dealPrice: string;
  endTime: string;
}

export interface UserContact {
  phone: string;
  whatsapp: string;
}

export interface ShippingInfo {
    company: string;
    trackingNumber: string;
}

export type UserReputation = 'New Seller' | 'Rising Star' | 'Trusted Seller' | 'Verified Pro';

export type AdminSection = 
  | 'dashboard'
  | 'users'
  | 'ads'
  | 'reviews'
  | 'features'
  | 'content'
  | 'external_ads'
  | 'settings'
  | 'financials'
  | 'ai_tools'
  | 'social_support'
  | 'smart_safepay'
  | 'negotiations';

export interface Ad {
  id: string;
  title: string;
  description: string;
  price: string;
  minQuantity: number;
  category: string;
  subcategory?: string;
  province: string;
  images: string[];
  userId: string;
  featured: boolean;
  featuredUntil?: string;
  status: 'pending' | 'approved' | 'rejected';
  rejectionReason?: string;
  auctionId?: string; 
  priceTiers?: PriceTier[];
  views: number;
  saves: number;
  flashDeal?: FlashDeal;
  aiQualityVerificationStatus: 'none' | 'pending' | 'verified' | 'rejected';
  isCharitable?: boolean;
}

export type UserRole = 'admin' | 'moderator' | 'support' | 'wholesaler' | 'retailer';


export interface StockWatch {
    id: string;
    userId: string;
    keywords: string;
    category: string;
    province: string;
}

export interface User {
  id: string;
  email: string;
  password?: string;
  name: string;
  role: UserRole;
  profilePicture: string;
  storeName?: string;
  storeLocation?: string;
  contact: UserContact;
  favoriteAdIds: string[];
  watchedAdIds: string[];
  banned?: boolean;
  reputation: UserReputation;
  isVerified?: boolean;
  lastSeen?: string;
  // Referral System
  referralCode: string;
  referredBy?: string;
  referrals: string[];
  availableFeatureRewards: number;
  pendingReferralReward?: boolean;
  webAuthnCredentialId?: string;
}

export interface Category {
  id:string;
  name: string;
  subcategories: string[];
}

export interface Province {
    id: string;
    name: string;
}

export enum AIAssistantMode {
  SEARCH = 'search',
  AD_CREATION = 'ad_creation',
  NONE = 'none'
}

export type MessageStatus = 'sent' | 'delivered' | 'read';

interface BaseChatMessage {
  id: string;
  conversationId: string;
  senderId: string;
  timestamp: string;
  status: MessageStatus;
  isSending?: boolean;
}

export interface TextChatMessage extends BaseChatMessage {
  type: 'text';
  text: string;
}

export interface AdLinkDetails {
  adId: string;
  title: string;
  price: string;
  image: string;
}

export interface AdLinkChatMessage extends BaseChatMessage {
  type: 'ad_link';
  adDetails: AdLinkDetails;
}

export interface DealMemoChatMessage extends BaseChatMessage {
  type: 'deal_memo';
  memo: DealMemo;
}

export type ChatMessage = TextChatMessage | AdLinkChatMessage | DealMemoChatMessage;

export interface ChatConversation {
  id: string;
  participantIds: string[];
  lastMessage: ChatMessage;
}

export interface Review {
  id: string;
  adId: string;
  reviewerId: string;
  sellerId: string;
  rating: number; // 1 to 5
  comment: string;
  timestamp: string;
}

export interface ExternalAd {
    id: string;
    companyName: string;
    imageUrl: string;
    targetUrl: string;
    isActive: boolean;
}

export type AnnouncementType = 'info' | 'warning' | 'offer';

export interface AppSettings {
    googleAdsEnabled: boolean;
    featuredAdPrice: number;
    announcementText: string;
    announcementType: AnnouncementType;
    isAnnouncementActive: boolean;
    maintenanceMode: boolean;
    zainCashNumber: string;
    asiaPayNumber: string;
    charityProgramDescription: string;
    smallProjectsProgramDescription: string;
}

export type NotificationType = 
  | 'new_message' 
  | 'new_review' 
  | 'ad_approved' 
  | 'ad_rejected' 
  | 'welcome'
  | 'auction_won'
  | 'auction_outbid'
  | 'new_offer'
  | 'watched_ad_price_change'
  | 'new_ad_for_stock_watch'
  | 'new_rfq_offer'
  | 'suspicious_activity'
  | 'referral_reward';

export interface Notification {
  id: string;
  userId: string;
  type: NotificationType;
  text: string;
  link: string; // Path to navigate to
  isRead: boolean;
  timestamp: string;
  relatedId?: string; // e.g., conversationId or adId
}

export type ToastType = 'success' | 'error';
export interface Toast {
    id: string;
    message: string;
    type: ToastType;
}

export interface RequestForQuotation {
  id: string;
  userId: string;
  productName: string;
  category: string;
  quantity: number;
  details: string;
  province: string;
  timestamp: string;
  status: 'open' | 'closed';
}

export interface Offer {
  id: string;
  rfqId: string;
  sellerId: string;
  pricePerUnit: number;
  comments: string;
  timestamp: string;
}

export interface FeatureFlag {
  id: string;
  name: string;
  description: string;
  isEnabled: boolean;
}

// --- Auctions & Offers ---
export interface Bid {
  userId: string;
  amount: number;
  timestamp: string;
}

export interface Auction {
  id: string;
  adId: string;
  startTime: string;
  endTime: string;
  startPrice: number;
  currentPrice: number;
  bids: Bid[];
  status: 'active' | 'ended';
  winnerId?: string;
}

export interface PersonalizedOffer {
    id: string;
    adId: string;
    sellerId: string;
    discountPercentage: number;
    timestamp: string;
}

export interface MarketBrief {
    id: string;
    date: string;
    content: string;
}

export interface MarketAnalysis {
    priceIndex: string;
    emergingOpportunities: string;
    competitorAnalysis: string;
}

export type ProfileTab = 'favorites' | 'myAds' | 'reviews' | 'settings' | 'watched' | 'stockWatch' | 'myRfqs' | 'myBids';

// --- Admin Panel Specific Types ---
export type SystemHealthStatus = 'operational' | 'degraded' | 'outage';

export interface SystemHealth {
    apiStatus: SystemHealthStatus;
    databaseStatus: SystemHealthStatus;
    aiServiceStatus: SystemHealthStatus;
}

export interface SuspiciousActivity {
    id: string;
    description: string;
    relatedUserId?: string;
    relatedAdId?: string;
    timestamp: string;
    priority: 'low' | 'medium' | 'high';
}

// --- World-Class Features ---
export interface Opportunity {
  id: string;
  userId: string;
  type: 'rfq_match' | 'ad_match';
  title: string;
  description: string;
  relatedId: string; // Ad ID or RFQ ID
  timestamp: string;
}

export interface DealMemo {
  id: string;
  conversationId: string;
  product: string;
  quantity: string;
  price: string;
  terms: string;
  status: 'pending' | 'approved' | 'rejected';
  approverIds: string[];
  timestamp: string;
  smartPaymentId?: string;
}

export interface OrderEvent {
  timestamp: string;
  status: SmartPayment['status'];
  description: string;
}

export interface SmartPayment {
  id: string;
  memoId: string;
  amount: number;
  status: 'pending_deposit' | 'funds_deposited' | 'shipped' | 'completed' | 'disputed';
  buyerId: string;
  sellerId: string;
  shippingInfo?: ShippingInfo;
  orderHistory: OrderEvent[];
  disputeReason?: string;
}


export interface NegotiationMessage {
    id: string;
    sender: 'bot' | 'seller';
    text: string;
    timestamp: string;
}
export interface NegotiationSession {
    id: string;
    adId: string;
    buyerId: string;
    sellerId: string;
    status: 'active' | 'accepted' | 'rejected' | 'cancelled';
    history: NegotiationMessage[];
    // Buyer's private parameters
    targetPrice: number;
    lowestPrice: number;
}

export interface PartnershipScore {
  score: number;
  analysis: string;
}