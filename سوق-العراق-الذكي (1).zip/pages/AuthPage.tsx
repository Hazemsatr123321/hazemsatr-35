import React, { useState, useMemo } from 'react';
import { Input } from '../components/common/Input';
import { Button } from '../components/common/Button';
import { SparklesIcon } from '../components/icons/SparklesIcon';
import { useUser } from '../contexts/UserContext';
import { User, UserRole } from '../types';
import { LoadingSpinner } from '../components/common/LoadingSpinner';
import { useAdmin } from '../contexts/AdminContext';
import { FingerprintIcon } from '../components/icons/FingerprintIcon';

interface AuthPageProps {
    onLoginSuccess: (user: User) => void;
    onRegisterSuccess: (user: User) => void;
    onNavigate: (path: string) => void;
    referrerId?: string;
}

const base64URLToBuffer = (base64URL: string): ArrayBuffer => {
    const base64 = base64URL.replace(/-/g, '+').replace(/_/g, '/');
    const padLength = (4 - (base64.length % 4)) % 4;
    const padded = base64 + '='.repeat(padLength);
    const binary_string = atob(padded);
    const len = binary_string.length;
    const bytes = new Uint8Array(len);
    for (let i = 0; i < len; i++) {
        bytes[i] = binary_string.charCodeAt(i);
    }
    return bytes.buffer;
};

const AuthFormWrapper: React.FC<{ children: React.ReactNode, onSubmit: (e: React.FormEvent) => void }> = ({ children, onSubmit }) => (
    <form onSubmit={onSubmit} className="space-y-5 animate-fadeInUp">
        {children}
    </form>
);

export const AuthPage: React.FC<AuthPageProps> = ({ onLoginSuccess, onRegisterSuccess, onNavigate, referrerId }) => {
    const [mode, setMode] = useState<'login' | 'register'>('login');
    const [error, setError] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const { setCurrentUser } = useUser();
    const { users, addUser, updateUser } = useAdmin();

    // Login state
    const [loginEmail, setLoginEmail] = useState('');
    const [loginPassword, setLoginPassword] = useState('');

    // Register state
    const [regName, setRegName] = useState('');
    const [regEmail, setRegEmail] = useState('');
    const [regPhone, setRegPhone] = useState('');
    const [regPassword, setRegPassword] = useState('');
    const [regConfirmPassword, setRegConfirmPassword] = useState('');
    const [regRole, setRegRole] = useState<UserRole>('retailer');
    const [regStoreName, setRegStoreName] = useState('');

    const biometricUser = useMemo(() => users.find(u => !!u.webAuthnCredentialId), [users]);
    const isBiometricSupported = window.PublicKeyCredential && biometricUser;

    const handleBiometricLogin = async () => {
        if (!isBiometricSupported || !biometricUser) return;

        setIsLoading(true);
        setError('');
        try {
            const challenge = new Uint8Array(32);
            window.crypto.getRandomValues(challenge);
            
            const credentialIdBuffer = base64URLToBuffer(biometricUser.webAuthnCredentialId!);

            const credential = await navigator.credentials.get({
                publicKey: {
                    challenge,
                    allowCredentials: [{
                        type: 'public-key',
                        id: credentialIdBuffer,
                    }],
                    userVerification: 'required',
                    timeout: 60000,
                }
            });

            if (credential) {
                // In a real app, you'd send the assertion to the server for verification.
                // Here, we'll just log the user in.
                setCurrentUser(biometricUser);
                onLoginSuccess(biometricUser);
            }
        } catch (err) {
            console.error("Biometric login failed:", err);
            setError("فشل تسجيل الدخول بالبصمة. حاول بكلمة المرور.");
        } finally {
            setIsLoading(false);
        }
    };

    const handleLogin = (e: React.FormEvent) => {
        e.preventDefault();
        setError('');
        
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(loginEmail)) {
            setError('صيغة البريد الإلكتروني غير صحيحة.');
            return;
        }

        setIsLoading(true);
        setTimeout(() => { // Simulate network delay
            const user = users.find(u => u.email === loginEmail && u.password === loginPassword);
            if (user) {
                if(user.banned) {
                    setError('هذا الحساب محظور.');
                } else {
                    setCurrentUser(user);
                    onLoginSuccess(user);
                }
            } else {
                setError('البريد الإلكتروني أو كلمة المرور غير صحيحة.');
            }
            setIsLoading(false);
        }, 1000);
    };

    const handleRegister = (e: React.FormEvent) => {
        e.preventDefault();
        setError('');

        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(regEmail)) {
            setError('صيغة البريد الإلكتروني غير صحيحة.');
            return;
        }

        const phoneRegex = /^07[0-9]{9}$/;
        if (!phoneRegex.test(regPhone)) {
            setError('صيغة رقم هاتف التواصل غير صحيحة. يجب أن يبدأ بـ 07 ويتكون من 11 رقماً.');
            return;
        }

        if (!regName || !regEmail || !regPassword) {
            setError('الرجاء ملء جميع الحقول المطلوبة.');
            return;
        }
        if (regPassword !== regConfirmPassword) {
            setError('كلمتا المرور غير متطابقتين.');
            return;
        }
         if (regPassword.length < 6) {
            setError('يجب أن تكون كلمة المرور 6 أحرف على الأقل.');
            return;
        }
        if (users.some(u => u.email === regEmail)) {
            setError('هذا البريد الإلكتروني مسجل بالفعل.');
            return;
        }

        setIsLoading(true);
        setTimeout(() => { // Simulate network delay
            let referredBy = undefined;
            if (referrerId) {
                const referrer = users.find(u => u.referralCode === referrerId);
                if (referrer) {
                    referredBy = referrer.id;
                }
            }

            const newUser: User = {
                id: `user_${Date.now()}`,
                email: regEmail,
                password: regPassword,
                name: regName,
                role: regRole,
                profilePicture: `https://i.pravatar.cc/150?u=${regEmail}`,
                storeName: regStoreName || undefined,
                contact: { phone: regPhone, whatsapp: regPhone },
                favoriteAdIds: [],
                watchedAdIds: [],
                reputation: 'New Seller',
                isVerified: false,
                referralCode: `REF${Date.now().toString().slice(-6)}`,
                referrals: [],
                availableFeatureRewards: 0,
                lastSeen: new Date().toISOString(),
                referredBy: referredBy,
                pendingReferralReward: !!referredBy
            };
            
            addUser(newUser);
            if (referredBy) {
                const referrer = users.find(u => u.id === referredBy);
                if (referrer) {
                    updateUser(referredBy, {
                        referrals: [...referrer.referrals, newUser.id]
                    });
                }
            }

            setCurrentUser(newUser);
            onRegisterSuccess(newUser);
            setIsLoading(false);
        }, 1500);
    };

    return (
        <div className="min-h-screen bg-brand-primary text-brand-text flex items-center justify-center p-4 luxury-homepage-bg">
            <div className="w-full max-w-md mx-auto">
                <div className="text-center mb-8 animate-fadeInUp">
                    <SparklesIcon className="w-16 h-16 text-brand-accent mx-auto mb-4" />
                    <h1 className="text-4xl font-extrabold text-gradient-gold">سوق العراق الذكي</h1>
                </div>

                <div className="bg-brand-secondary/50 backdrop-blur-xl p-8 rounded-2xl shadow-2xl border border-brand-accent/20 min-h-[450px]">
                    {isLoading ? (
                        <div className="flex items-center justify-center h-full pt-10">
                           <LoadingSpinner text={mode === 'login' ? 'جاري تسجيل الدخول...' : 'جاري إنشاء الحساب...'} />
                        </div>
                    ) : (
                        <>
                            <div className="flex justify-center border-b border-gray-700 mb-6">
                                <button
                                    onClick={() => { setMode('login'); setError(''); }}
                                    className={`px-6 py-3 text-lg font-bold transition-colors duration-300 border-b-2 ${mode === 'login' ? 'text-brand-accent border-brand-accent' : 'text-brand-text-secondary border-transparent hover:text-white'}`}
                                >
                                    تسجيل الدخول
                                </button>
                                <button
                                    onClick={() => { setMode('register'); setError(''); }}
                                    className={`px-6 py-3 text-lg font-bold transition-colors duration-300 border-b-2 ${mode === 'register' ? 'text-brand-accent border-brand-accent' : 'text-brand-text-secondary border-transparent hover:text-white'}`}
                                >
                                    إنشاء حساب
                                </button>
                            </div>

                            {mode === 'login' ? (
                                <AuthFormWrapper onSubmit={handleLogin}>
                                    <Input label="البريد الإلكتروني" id="email" type="email" value={loginEmail} onChange={(e) => setLoginEmail(e.target.value)} placeholder="example@example.com" required />
                                    <Input label="كلمة المرور" id="password" type="password" value={loginPassword} onChange={(e) => setLoginPassword(e.target.value)} placeholder="password123" required />
                                    
                                    {isBiometricSupported && (
                                        <div className="pt-2">
                                            <Button type="button" onClick={handleBiometricLogin} variant="outline" className="w-full flex items-center justify-center gap-2">
                                                <FingerprintIcon className="w-5 h-5"/>
                                                الدخول بالبصمة لـ {biometricUser.name.split(' ')[0]}
                                            </Button>
                                        </div>
                                    )}

                                    <div className="text-right -mt-2">
                                        <a href="#" onClick={(e) => e.preventDefault()} className="text-sm text-brand-accent hover:underline">
                                            هل نسيت كلمة المرور؟
                                        </a>
                                    </div>
                                    {error && <p className="text-red-400 text-sm text-center pt-2">{error}</p>}
                                    <Button type="submit" className="w-full !mt-8" disabled={isLoading}>دخول</Button>
                                </AuthFormWrapper>
                            ) : (
                                <AuthFormWrapper onSubmit={handleRegister}>
                                    <Input label="الاسم الكامل أو اسم الشركة" id="regName" type="text" value={regName} onChange={e => setRegName(e.target.value)} required />
                                    <Input label="البريد الإلكتروني" id="regEmail" type="email" value={regEmail} onChange={e => setRegEmail(e.target.value)} placeholder="example@example.com" required />
                                    <div>
                                      <Input label="رقم الهاتف (للتواصل)" id="regPhone" type="tel" value={regPhone} onChange={e => setRegPhone(e.target.value)} placeholder="07XXXXXXXXX" required />
                                      <p className="-mt-3 text-xs text-brand-text-secondary text-center">
                                          لن يتم استخدام رقم هاتفك لتسجيل الدخول.
                                      </p>
                                    </div>
                                    <Input label="كلمة المرور" id="regPassword" type="password" value={regPassword} onChange={e => setRegPassword(e.target.value)} required />
                                    <Input label="تأكيد كلمة المرور" id="regConfirmPassword" type="password" value={regConfirmPassword} onChange={e => setRegConfirmPassword(e.target.value)} required />

                                    <div>
                                        <label className="block text-brand-text-secondary text-sm font-bold mb-2">نوع الحساب</label>
                                        <select value={regRole} onChange={e => setRegRole(e.target.value as UserRole)} className="w-full bg-brand-primary text-brand-text border-gray-600 rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-brand-accent">
                                            <option value="retailer">صاحب محل (مشترٍ)</option>
                                            <option value="wholesaler">تاجر جملة (بائع)</option>
                                        </select>
                                    </div>
                                    {regRole === 'wholesaler' && <Input label="اسم المتجر/المخزن (اختياري)" id="regStoreName" type="text" value={regStoreName} onChange={e => setRegStoreName(e.target.value)} />}
                                    {error && <p className="text-red-400 text-sm text-center pt-2">{error}</p>}
                                    <Button type="submit" className="w-full !mt-8" disabled={isLoading}>إنشاء الحساب</Button>
                                </AuthFormWrapper>
                            )}
                        </>
                    )}
                </div>
                 <div className="text-center mt-6">
                    <p className="text-sm text-brand-text-secondary mb-3">أو</p>
                    <Button onClick={() => onNavigate('/')} variant="outline" className="w-full">
                        المتابعة كزائر
                    </Button>
                </div>
            </div>
        </div>
    );
};