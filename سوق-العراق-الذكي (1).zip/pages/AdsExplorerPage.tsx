import React, { useState, useMemo, useEffect, useRef } from 'react';
import { AdCard } from '../components/AdCard';
import { Header } from '../components/Header';
import { useAdmin } from '../contexts/AdminContext';
import { SearchIcon } from '../components/icons/SearchIcon';
import { GavelIcon } from '../components/icons/GavelIcon';
import { Button } from '../components/common/Button';
import { RadarIcon } from '../components/icons/RadarIcon';
import { EmptyState } from '../components/common/EmptyState';
import { ClipboardIcon } from '../components/icons/ClipboardIcon';
import { useUser } from '../contexts/UserContext';
import { HandHeartIcon } from '../components/icons/HandHeartIcon';
import { AdCardSkeleton } from '../components/AdCardSkeleton';
import { ArrowDownIcon } from '../components/icons/ArrowDownIcon';

export const AdsExplorerPage: React.FC<{ 
    onNavigate: (path: string) => void,
    onOpenStockWatch: () => void,
}> = ({ onNavigate, onOpenStockWatch }) => {
  const { ads, categories, provinces, featureFlags } = useAdmin();
  const { currentUser } = useUser();
  const [filters, setFilters] = useState({
    searchQuery: '',
    category: 'الكل',
    subcategory: 'الكل',
    province: 'الكل',
    minPrice: '',
    maxPrice: ''
  });

  const [isLoading, setIsLoading] = useState(true);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [pullStartY, setPullStartY] = useState(0);
  const [pullDeltaY, setPullDeltaY] = useState(0);
  const containerRef = useRef<HTMLDivElement>(null);


  useEffect(() => {
    // Simulate initial data loading
    const timer = setTimeout(() => setIsLoading(false), 1200);
    return () => clearTimeout(timer);
  }, []);

  const handleRefresh = () => {
    if (isRefreshing) return;
    setIsRefreshing(true);
    // Simulate network request for refreshing
    setTimeout(() => {
        setIsRefreshing(false);
        setPullDeltaY(0);
    }, 1500);
  };

  // Pull-to-refresh logic
  const handleTouchStart = (e: React.TouchEvent<HTMLDivElement>) => {
    if (containerRef.current?.scrollTop === 0) {
      setPullStartY(e.targetTouches[0].clientY);
    }
  };

  const handleTouchMove = (e: React.TouchEvent<HTMLDivElement>) => {
    if (containerRef.current?.scrollTop === 0 && pullStartY > 0) {
      const delta = e.targetTouches[0].clientY - pullStartY;
      if (delta > 0) {
        e.preventDefault();
        setPullDeltaY(Math.min(delta, 120)); // Limit pull distance
      }
    }
  };

  const handleTouchEnd = () => {
    if (pullDeltaY > 80) { // Threshold to trigger refresh
      handleRefresh();
    } else {
      setPullDeltaY(0);
    }
    setPullStartY(0);
  };


  const isRfqEnabled = featureFlags.find(f => f.id === 'requestForQuotation')?.isEnabled ?? false;

  const handleFilterChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFilters(prev => ({ ...prev, [name]: value }));
  };

  const subcategories = useMemo(() => {
    if (filters.category === 'الكل') return [];
    const selected = categories.find(c => c.name === filters.category);
    return selected ? selected.subcategories : [];
  }, [filters.category, categories]);

  const filteredAds = useMemo(() => {
    return ads.filter(ad => {
      // Show only approved ads
      if (ad.status !== 'approved') return false;

      const { searchQuery, category, subcategory, province, minPrice, maxPrice } = filters;
      
      const queryMatch = searchQuery ? (ad.title.toLowerCase().includes(searchQuery.toLowerCase()) || ad.description.toLowerCase().includes(searchQuery.toLowerCase())) : true;
      const categoryMatch = category === 'الكل' || ad.category === category;
      const subcategoryMatch = subcategory === 'الكل' || !subcategory || ad.subcategory === subcategory;
      const provinceMatch = province === 'الكل' || ad.province === province;
      
      const price = parseFloat(ad.price.replace(/[^0-9]/g, ''));
      const minPriceNum = minPrice ? parseFloat(minPrice) : 0;
      const maxPriceNum = maxPrice ? parseFloat(maxPrice) : Infinity;
      const priceMatch = !isNaN(price) ? (price >= minPriceNum && price <= maxPriceNum) : true;

      return queryMatch && categoryMatch && subcategoryMatch && provinceMatch && priceMatch;
    }).sort((a, b) => (b.featured ? 1 : 0) - (a.featured ? 1 : 0));
  }, [ads, filters]);

  return (
    <div className="min-h-screen text-brand-text bg-brand-primary flex flex-col">
      <Header variant="page" title="تصفح الإعلانات" onBack={() => onNavigate('/')} onNavigate={onNavigate} />

      <main 
        ref={containerRef}
        className="container mx-auto p-4 pb-24 flex-grow overflow-y-auto"
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
        style={{ transform: `translateY(${isRefreshing ? 60 : pullDeltaY / 2.5}px)`, transition: 'transform 0.3s ease' }}
      >
        <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-full flex items-center justify-center p-4" style={{transition: 'opacity 0.3s'}}>
            <div className={`transition-transform duration-300 ${isRefreshing ? 'animate-spin' : ''}`} style={{ transform: `rotate(${pullDeltaY * 2}deg)`}}>
                <ArrowDownIcon className="w-6 h-6 text-brand-text-secondary" />
            </div>
        </div>

        {/* Filters Section */}
        <div className="bg-brand-secondary/80 backdrop-blur-md p-4 rounded-2xl mb-8 space-y-4">
          <div className="relative">
            <input
              type="text"
              name="searchQuery"
              value={filters.searchQuery}
              onChange={handleFilterChange}
              placeholder="ابحث بالاسم أو الوصف..."
              className="w-full bg-brand-primary text-brand-text placeholder-brand-text-secondary border border-gray-600 rounded-lg py-3 pr-10 pl-4 focus:outline-none focus:ring-2 focus:ring-brand-accent"
            />
            <div className="absolute inset-y-0 right-0 flex items-center pr-3 text-brand-text-secondary">
              <SearchIcon className="h-5 w-5"/>
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-3 gap-4">
            <select name="category" value={filters.category} onChange={handleFilterChange} className="w-full bg-brand-primary text-brand-text border-gray-600 rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-brand-accent">
              <option value="الكل">كل الفئات</option>
              {categories.map(cat => <option key={cat.id} value={cat.name}>{cat.name}</option>)}
            </select>
            <select name="province" value={filters.province} onChange={handleFilterChange} className="w-full bg-brand-primary text-brand-text border-gray-600 rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-brand-accent">
              <option value="الكل">كل المحافظات</option>
              {provinces.map(prov => <option key={prov.id} value={prov.name}>{prov.name}</option>)}
            </select>
             <Button onClick={onOpenStockWatch} variant="secondary" className="w-full flex items-center justify-center gap-2">
                <RadarIcon className="h-5 w-5" />
                <span>إنشاء رادار سوق</span>
            </Button>
          </div>
           <div className="flex justify-end pt-2 gap-4 flex-wrap">
              <Button onClick={() => onNavigate('/social-support')} variant="outline" className="!py-2 !px-4 !border-blue-500 !text-blue-400 hover:!bg-blue-500 hover:!text-white flex items-center justify-center gap-2">
                  <HandHeartIcon className="h-5 w-5" />
                  <span>دعم الخير والمشاريع</span>
              </Button>
             {isRfqEnabled && (
                <Button onClick={() => onNavigate('/rfqs')} variant="outline" className="!py-2 !px-4 !border-cyan-500 !text-cyan-400 hover:!bg-cyan-500 hover:!text-white flex items-center justify-center gap-2">
                    <ClipboardIcon className="h-5 w-5" />
                    <span>طلبات عروض الأسعار</span>
                </Button>
              )}
             <Button onClick={() => onNavigate('/auctions')} variant="outline" className="!py-2 !px-4 !border-red-500 !text-red-400 hover:!bg-red-500 hover:!text-white flex items-center justify-center gap-2">
              <GavelIcon className="h-5 w-5" />
              <span>عرض المزادات</span>
            </Button>
          </div>
        </div>

        {/* Ads Grid */}
        {isLoading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {Array.from({ length: 8 }).map((_, index) => <AdCardSkeleton key={index} />)}
          </div>
        ) : filteredAds.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filteredAds.map((ad, index) => (
               <div key={ad.id} className="animate-fadeInUp" style={{ animationDelay: `${index * 50}ms`}}>
                  <AdCard ad={ad} onClick={() => onNavigate(`/ad/${ad.id}`)} />
               </div>
            ))}
          </div>
        ) : (
          <div className="col-span-full py-16">
            <EmptyState
              icon={<SearchIcon />}
              title="لا توجد نتائج"
              message="لم نعثر على أي إعلانات تطابق بحثك الحالي. حاول تعديل الفلاتر أو البحث عن شيء آخر."
            />
          </div>
        )}
      </main>
    </div>
  );
};
