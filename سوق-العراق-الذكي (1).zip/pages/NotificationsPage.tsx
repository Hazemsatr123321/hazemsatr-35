import React, { useMemo } from 'react';
import { useAdmin } from '../contexts/AdminContext';
import { Header } from '../components/Header';
import type { Notification, NotificationType } from '../types';
import { Button } from '../components/common/Button';
import { MessageSquareIcon } from '../components/icons/MessageSquareIcon';
import { StarIcon } from '../components/icons/StarIcon';
import { SparklesIcon } from '../components/icons/SparklesIcon';
import { useUser } from '../contexts/UserContext';

// Helper function to get icon based on notification type
const getNotificationIcon = (type: NotificationType) => {
    switch (type) {
        case 'new_message':
            return <MessageSquareIcon className="w-6 h-6 text-blue-400" />;
        case 'new_review':
            return <StarIcon className="w-6 h-6 text-yellow-400" />;
        case 'ad_approved':
            return <svg xmlns="http://www.w3.org/2000/svg" className="w-6 h-6 text-green-400" viewBox="0 0 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>;
        case 'welcome':
            return <SparklesIcon className="w-6 h-6 text-brand-accent" />;
        default:
            return <div className="w-6 h-6 bg-gray-500 rounded-full" />;
    }
};

// Helper to group notifications
const groupNotificationsByDate = (notifications: Notification[]) => {
    const groups: { [key: string]: Notification[] } = {
        'اليوم': [],
        'الأمس': [],
        'أقدم': [],
    };

    const today = new Date();
    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);

    notifications.forEach(notification => {
        const notificationDate = new Date(notification.timestamp);
        if (notificationDate.toDateString() === today.toDateString()) {
            groups['اليوم'].push(notification);
        } else if (notificationDate.toDateString() === yesterday.toDateString()) {
            groups['الأمس'].push(notification);
        } else {
            groups['أقدم'].push(notification);
        }
    });

    return groups;
};

export const NotificationsPage: React.FC<{ onNavigate: (path: string) => void }> = ({ onNavigate }) => {
    const { notifications, markAsRead, markAllAsRead, clearAllNotifications } = useAdmin();
    const { currentUser } = useUser();
    
    const userNotifications = useMemo(() => {
        if (!currentUser) return [];
        return notifications.filter(n => n.userId === currentUser.id).sort((a,b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
    }, [notifications, currentUser]);

    if (!currentUser) {
        onNavigate('/auth');
        return null;
    }

    const groupedNotifications = groupNotificationsByDate(userNotifications);

    const handleNotificationClick = (notification: Notification) => {
        markAsRead(notification.id);
        onNavigate(notification.link);
    };
    
    const handleClearAll = () => {
        if (window.confirm('هل أنت متأكد من حذف جميع الإشعارات؟ لا يمكن التراجع عن هذا الإجراء.')) {
            clearAllNotifications(currentUser.id);
        }
    }
    
    const handleMarkAllRead = () => {
        markAllAsRead(currentUser.id);
    }

    return (
        <div className="bg-brand-primary min-h-screen text-brand-text">
            <Header variant="page" title="الإشعارات" onBack={() => onNavigate('/')} onNavigate={onNavigate}/>
            <main className="container mx-auto p-4 pb-24">
                <div className="flex justify-between items-center mb-6">
                    <h1 className="text-3xl font-bold text-brand-text">قائمة الإشعارات</h1>
                    {userNotifications.length > 0 && (
                        <div className="flex gap-2">
                            <Button onClick={handleMarkAllRead} variant="secondary" className="!text-sm !py-1.5 !px-3">تعليم الكل كمقروء</Button>
                            <Button onClick={handleClearAll} variant="outline" className="!border-red-500 !text-red-500 hover:!bg-red-500 hover:!text-brand-primary !text-sm !py-1.5 !px-3">حذف الكل</Button>
                        </div>
                    )}
                </div>
                
                {userNotifications.length > 0 ? (
                    <div className="space-y-6">
                        {Object.entries(groupedNotifications).map(([groupTitle, groupNotifications]) => (
                            groupNotifications.length > 0 && (
                                <div key={groupTitle}>
                                    <h2 className="text-lg font-semibold text-brand-text-secondary mb-3">{groupTitle}</h2>
                                    <div className="bg-brand-secondary rounded-2xl overflow-hidden space-y-px">
                                        {groupNotifications.map(notification => (
                                            <div
                                                key={notification.id}
                                                onClick={() => handleNotificationClick(notification)}
                                                className={`p-4 flex items-center gap-4 cursor-pointer transition-colors ${
                                                    notification.isRead ? 'bg-brand-secondary hover:bg-brand-primary/50' : 'bg-blue-900/30 hover:bg-blue-900/50'
                                                }`}
                                            >
                                                {!notification.isRead && <div className="w-2.5 h-2.5 bg-blue-500 rounded-full flex-shrink-0 animate-pulse"></div>}
                                                <div className="flex-shrink-0 ml-2">{getNotificationIcon(notification.type)}</div>
                                                <div className="flex-grow">
                                                    <p className="text-brand-text leading-tight">{notification.text}</p>
                                                    <p className="text-xs text-brand-text-secondary mt-1">{new Date(notification.timestamp).toLocaleString('ar-IQ')}</p>
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            )
                        ))}
                    </div>
                ) : (
                    <div className="text-center py-20 bg-brand-secondary rounded-2xl">
                        <svg xmlns="http://www.w3.org/2000/svg" className="mx-auto h-16 w-16 text-brand-text-secondary" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" /></svg>
                        <p className="mt-4 text-xl text-brand-text-secondary">لا توجد لديك إشعارات جديدة.</p>
                        <p className="mt-2 text-sm text-gray-500">سنعلمك عندما يحدث شيء جديد.</p>
                    </div>
                )}
            </main>
        </div>
    );
};