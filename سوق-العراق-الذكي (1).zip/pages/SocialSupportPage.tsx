import React, { useState, useMemo } from 'react';
import { Header } from '../components/Header';
import { useAdmin } from '../contexts/AdminContext';
import { HandHeartIcon } from '../components/icons/HandHeartIcon';
import { AdCard } from '../components/AdCard';
import { EmptyState } from '../components/common/EmptyState';
import { FileTextIcon } from '../components/icons/FileTextIcon';
import { AwardIcon } from '../components/icons/AwardIcon';

type SocialTab = 'needy' | 'projects';

export const SocialSupportPage: React.FC<{ onNavigate: (path: string) => void }> = ({ onNavigate }) => {
    const { ads, users, settings } = useAdmin();
    const [activeTab, setActiveTab] = useState<SocialTab>('needy');

    const charitableAds = useMemo(() => {
        return ads.filter(ad => ad.isCharitable && ad.status === 'approved' && ad.category === 'مواد غذائية');
    }, [ads]);

    const smallProjectAds = useMemo(() => {
        return ads.filter(ad => {
            if (!ad.featured) return false;
            const user = users.find(u => u.id === ad.userId);
            // We assume retailers are small projects for this feature
            return user?.role === 'retailer';
        });
    }, [ads, users]);

    const TabButton: React.FC<{ title: string, count: number, isActive: boolean, onClick: () => void, icon: React.ReactNode }> = ({ title, count, isActive, onClick, icon }) => (
        <button
            onClick={onClick}
            className={`flex-1 p-4 text-center font-bold text-lg border-b-4 transition-all duration-300 flex items-center justify-center gap-3 ${
                isActive ? 'border-brand-accent text-brand-accent bg-brand-secondary' : 'border-transparent text-brand-text-secondary hover:bg-brand-secondary/50'
            }`}
        >
            {icon}
            {title}
            <span className={`px-2.5 py-1 rounded-full text-sm font-semibold transition-colors ${isActive ? 'bg-brand-accent text-brand-primary' : 'bg-brand-primary text-brand-text'}`}>
                {count}
            </span>
        </button>
    );

    return (
        <div className="min-h-screen bg-brand-primary text-brand-text">
            <Header variant="page" title="دعم الخير والمشاريع" onBack={() => onNavigate('/ads')} onNavigate={onNavigate} />
            <main className="container mx-auto p-4 pb-24">
                <div className="text-center mb-12">
                    <HandHeartIcon className="w-16 h-16 text-brand-accent mx-auto mb-4" />
                    <h1 className="text-4xl md:text-5xl font-extrabold text-gradient-gold">
                        مبادرات سوق العراق الذكي
                    </h1>
                    <p className="mt-4 text-lg text-brand-text-secondary max-w-2xl mx-auto">
                        نؤمن بدورنا في دعم المجتمع. هنا تجد مبادراتنا لدعم المحتاجين وتشجيع المشاريع الناشئة.
                    </p>
                </div>

                <div className="bg-brand-secondary rounded-2xl overflow-hidden shadow-lg">
                    {/* Tabs */}
                    <div className="flex">
                        <TabButton
                            title="دعم الفقراء"
                            count={charitableAds.length}
                            isActive={activeTab === 'needy'}
                            onClick={() => setActiveTab('needy')}
                            icon={<HandHeartIcon className="w-6 h-6"/>}
                        />
                        <TabButton
                            title="دعم المشاريع الصغيرة"
                            count={smallProjectAds.length}
                            isActive={activeTab === 'projects'}
                            onClick={() => setActiveTab('projects')}
                            icon={<AwardIcon className="w-6 h-6"/>}
                        />
                    </div>

                    {/* Content */}
                    <div className="p-6">
                        {activeTab === 'needy' && (
                            <div className="animate-fadeInUp">
                                <p className="text-center text-brand-text-secondary mb-8">{settings.charityProgramDescription}</p>
                                {charitableAds.length > 0 ? (
                                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                                        {charitableAds.map(ad => <AdCard key={ad.id} ad={ad} onClick={() => onNavigate(`/ad/${ad.id}`)} />)}
                                    </div>
                                ) : (
                                    <EmptyState icon={<FileTextIcon />} title="لا توجد إعلانات خيرية حالياً" message="لا يوجد تجار مشاركون في هذه المبادرة في الوقت الحالي. كن أول المشاركين!" />
                                )}
                            </div>
                        )}

                        {activeTab === 'projects' && (
                             <div className="animate-fadeInUp">
                                <p className="text-center text-brand-text-secondary mb-8">{settings.smallProjectsProgramDescription}</p>
                                 {smallProjectAds.length > 0 ? (
                                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                                        {smallProjectAds.map(ad => <AdCard key={ad.id} ad={ad} onClick={() => onNavigate(`/ad/${ad.id}`)} />)}
                                    </div>
                                ) : (
                                    <EmptyState icon={<AwardIcon />} title="لا توجد مشاريع مدعومة حالياً" message="تقوم الإدارة باختيار المشاريع بشكل أسبوعي. تفقد هذه الصفحة قريباً!" />
                                )}
                            </div>
                        )}
                    </div>
                </div>
            </main>
        </div>
    );
};
