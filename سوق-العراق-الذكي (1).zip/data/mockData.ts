import { User, Ad, ExternalAd, AppSettings, Category, Province, Review, Notification, RequestForQuotation, Offer, FeatureFlag, Auction, PersonalizedOffer, StockWatch, MarketBrief, SystemHealth, SuspiciousActivity, Opportunity, DealMemo, SmartPayment, NegotiationSession, ChatConversation, ChatMessage } from '../types';

export const mockUsers: User[] = [
  {
    id: 'admin_user_1',
    email: 'admin@example.com',
    password: 'password123',
    name: 'أحمد المدير',
    role: 'admin',
    profilePicture: 'https://i.pravatar.cc/150?u=admin@example.com',
    storeName: 'إدارة سوق العراق الذكي',
    contact: { phone: '07700000001', whatsapp: '07700000001' },
    favoriteAdIds: [],
    watchedAdIds: [],
    reputation: 'Verified Pro',
    isVerified: true,
    referralCode: 'ADMINREF',
    referrals: [],
    availableFeatureRewards: 99,
  },
  {
    id: 'wholesaler_user_1',
    email: 'wholesaler@example.com',
    password: 'password123',
    name: 'شركة تجارة بغداد',
    role: 'wholesaler',
    profilePicture: 'https://i.pravatar.cc/150?u=wholesaler@example.com',
    storeName: 'مخازن الجملة الحديثة',
    storeLocation: 'بغداد',
    contact: { phone: '07800000002', whatsapp: '07800000002' },
    favoriteAdIds: ['ad_3'],
    watchedAdIds: [],
    reputation: 'Trusted Seller',
    isVerified: true,
    lastSeen: new Date(Date.now() - 3 * 60 * 1000).toISOString(),
    referralCode: 'SALE123',
    referrals: ['retailer_user_2'],
    availableFeatureRewards: 1,
  },
  {
    id: 'retailer_user_1',
    email: 'retailer@example.com',
    password: 'password123',
    name: 'أسواق النور',
    role: 'retailer',
    profilePicture: 'https://i.pravatar.cc/150?u=retailer@example.com',
    storeName: 'أسواق النور للمواد الغذائية',
    storeLocation: 'البصرة',
    contact: { phone: '07900000003', whatsapp: '07900000003' },
    favoriteAdIds: ['ad_1', 'ad_2'],
    watchedAdIds: [],
    reputation: 'New Seller',
    referralCode: 'SHOP456',
    referrals: [],
    availableFeatureRewards: 0,
  },
  {
    id: 'retailer_user_2',
    email: 'retailer2@example.com',
    password: 'password123',
    name: 'محمد علي',
    role: 'retailer',
    profilePicture: 'https://i.pravatar.cc/150?u=retailer2@example.com',
    storeName: 'محل محمد',
    storeLocation: 'أربيل',
    contact: { phone: '07500000004', whatsapp: '07500000004' },
    favoriteAdIds: [],
    watchedAdIds: [],
    reputation: 'New Seller',
    referralCode: 'BUY789',
    referrals: [],
    availableFeatureRewards: 0,
    referredBy: 'wholesaler_user_1',
    pendingReferralReward: true,
  }
];

export const mockCategories: Category[] = [
    { id: 'cat_1', name: 'مواد غذائية', subcategories: ['معلبات', 'زيوت', 'تمور', 'حلويات'] },
    { id: 'cat_2', name: 'ملابس', subcategories: ['ملابس رجالية', 'ملابس نسائية', 'ملابس أطفال'] },
    { id: 'cat_3', name: 'أجهزة كهربائية', subcategories: ['أجهزة مطبخ', 'شاشات', 'غسالات'] },
];

export const mockProvinces: Province[] = [
    { id: 'prov_1', name: 'بغداد' }, { id: 'prov_2', name: 'البصرة' }, { id: 'prov_3', name: 'أربيل' }, { id: 'prov_4', name: 'الأنبار' }, { id: 'prov_5', name: 'الموصل' }
];

export const mockAds: Ad[] = [
  {
    id: 'ad_1',
    title: 'تمر زاهدي عراقي درجة أولى',
    description: 'تمر زاهدي عراقي فاخر، محصول جديد. الكرتون يحتوي على 10 كيلو. البيع بالجملة فقط. أقل كمية للطلب 50 كرتون. السعر قابل للتفاوض للكميات الكبيرة.',
    price: '25,000 دينار / كارتون',
    minQuantity: 50,
    category: 'مواد غذائية',
    subcategory: 'تمور',
    province: 'بغداد',
    images: ['https://images.unsplash.com/photo-1595424263499-23213b76a0a7?q=80&w=400', 'https://images.unsplash.com/photo-1605657827965-78e5d3a0139b?q=80&w=400'],
    userId: 'wholesaler_user_1',
    featured: true,
    featuredUntil: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000).toISOString(),
    status: 'approved',
    views: 1250,
    saves: 80,
    aiQualityVerificationStatus: 'verified'
  },
  {
    id: 'ad_2',
    title: 'ملابس أطفال تركية صيفية',
    description: 'تشكيلة واسعة من ملابس الأطفال التركية لصيف 2024. قطن 100%. البيع بالجملة (سريات كاملة).',
    price: '8,000 دينار / قطعة',
    minQuantity: 100,
    category: 'ملابس',
    subcategory: 'ملابس أطفال',
    province: 'أربيل',
    images: ['https://images.unsplash.com/photo-1622771961183-c19590b9a91d?q=80&w=400', 'https://images.unsplash.com/photo-1620921969567-9514389d536a?q=80&w=400'],
    userId: 'wholesaler_user_1',
    featured: false,
    status: 'approved',
    views: 800,
    saves: 45,
    aiQualityVerificationStatus: 'none'
  },
  {
    id: 'ad_3',
    title: 'زيت طبخ عافية (كرتون 12)',
    description: 'زيت طبخ عافية الأصلي، حجم 1 لتر. الكرتون يحتوي على 12 قنينة. تاريخ إنتاج جديد.',
    price: '30,000 دينار / كرتون',
    minQuantity: 20,
    category: 'مواد غذائية',
    subcategory: 'زيوت',
    province: 'البصرة',
    images: ['https://images.unsplash.com/photo-1625246333195-78d9c38ad449?q=80&w=400'],
    userId: 'wholesaler_user_1',
    featured: true,
    status: 'pending',
    views: 0,
    saves: 0,
    aiQualityVerificationStatus: 'none',
    isCharitable: true,
  },
   {
    id: 'ad_4',
    title: 'شاشات تلفزيون LG سمارت 55 بوصة',
    description: 'شاشات LG موديل 2024، حجم 55 بوصة، سمارت. ضمان سنة كاملة. البيع بالجملة.',
    price: '650,000 دينار / قطعة',
    minQuantity: 10,
    category: 'أجهزة كهربائية',
    subcategory: 'شاشات',
    province: 'بغداد',
    images: ['https://images.unsplash.com/photo-1593359677879-a4bb92f829d1?q=80&w=400'],
    userId: 'wholesaler_user_1',
    featured: false,
    status: 'approved',
    views: 2100,
    saves: 150,
    aiQualityVerificationStatus: 'pending',
    auctionId: 'auction_1'
  },
];

export const mockReviews: Review[] = [
    { id: 'rev_1', adId: 'ad_1', reviewerId: 'retailer_user_1', sellerId: 'wholesaler_user_1', rating: 5, comment: 'بضاعة ممتازة وتعامل راقي. أنصح به بشدة.', timestamp: new Date().toISOString() }
];

export const mockAuctions: Auction[] = [
    {
        id: 'auction_1',
        adId: 'ad_4',
        startTime: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(),
        endTime: new Date(Date.now() + 48 * 60 * 60 * 1000).toISOString(),
        startPrice: 600000,
        currentPrice: 625000,
        bids: [{ userId: 'retailer_user_2', amount: 625000, timestamp: new Date().toISOString() }],
        status: 'active'
    }
];

export const mockRfqs: RequestForQuotation[] = [
    { id: 'rfq_1', userId: 'retailer_user_1', productName: 'معلبات فاصوليا نوع ممتاز', category: 'مواد غذائية', quantity: 200, details: 'أحتاج 200 كرتون فاصوليا معلبة، صناعة تركية أو عراقية درجة أولى.', province: 'البصرة', timestamp: new Date().toISOString(), status: 'open' }
];

export const mockOffers: Offer[] = [];

export const mockExternalAds: ExternalAd[] = [
    { id: 'ext_ad_1', companyName: 'شركة زين للشحن', imageUrl: 'https://images.unsplash.com/photo-1587293852726-70cdb1e8586b?q=80&w=600', targetUrl: '#', isActive: true }
];

export const mockPersonalizedOffers: PersonalizedOffer[] = [
    { id: 'offer_1', adId: 'ad_2', sellerId: 'wholesaler_user_1', discountPercentage: 10, timestamp: new Date().toISOString() }
];

export const mockNotifications: Notification[] = [
    { id: 'notif_1', userId: 'retailer_user_1', type: 'welcome', text: 'أهلاً بك في سوق العراق الذكي!', link: '/profile', isRead: false, timestamp: new Date().toISOString() }
];

export const mockStockWatches: StockWatch[] = [];

export const mockFeatureFlags: FeatureFlag[] = [
    { id: 'marketAdvisor', name: 'مستشار السوق الذكي', description: 'يفعل صفحة مستشار التسعير والفرص.', isEnabled: true },
    { id: 'dailyBriefing', name: 'الموجز اليومي للسوق', description: 'يفعل صفحة الموجز اليومي للسوق.', isEnabled: true },
    { id: 'requestForQuotation', name: 'طلبات عروض الأسعار (RFQ)', description: 'يسمح للمشترين بنشر طلبات.', isEnabled: true },
    { id: 'sellerReputation', name: 'نظام سمعة البائع', description: 'يعرض شارات السمعة للبائعين.', isEnabled: true },
];

export const mockDealMemos: DealMemo[] = [];
export const mockSmartPayments: SmartPayment[] = [];
export const mockNegotiationSessions: NegotiationSession[] = [];
export const mockOpportunities: Opportunity[] = [];
export const mockSuspiciousActivities: SuspiciousActivity[] = [];
export const mockMarketBriefs: MarketBrief[] = [];

export const mockSystemHealth: SystemHealth = {
    apiStatus: 'operational',
    databaseStatus: 'operational',
    aiServiceStatus: 'operational',
};

export const mockSettings: AppSettings = {
    googleAdsEnabled: true,
    featuredAdPrice: 15000,
    announcementText: 'عرض خاص: تمييز إعلانك بـ 10,000 دينار فقط هذا الأسبوع!',
    announcementType: 'offer',
    isAnnouncementActive: true,
    maintenanceMode: false,
    zainCashNumber: '07801234567',
    asiaPayNumber: '07701234567',
    charityProgramDescription: 'هذه الإعلانات مقدمة من تجار يشاركون في مبادرة دعم الأسر المتعففة. عند شرائك، يتم تخصيص جزء من البضاعة كتبرع.',
    smallProjectsProgramDescription: 'دعماً للشباب والمشاريع الصغيرة، تقوم إدارة التطبيق بتمييز إعلانات مختارة من هذه الفئة مجاناً لتشجيعهم.'
};

export const mockConversations: ChatConversation[] = [];
export const mockMessages: ChatMessage[] = [];