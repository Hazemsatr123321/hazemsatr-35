import React, { createContext, useState, useContext, ReactNode, useCallback, useMemo, useEffect } from 'react';
import { supabase } from '../services/supabaseClient';
import type { User, Ad, ExternalAd, AppSettings, UserRole, Category, Province, Review, Notification, RequestForQuotation, Offer, FeatureFlag, Auction, Bid, PersonalizedOffer, StockWatch, MarketBrief, SystemHealth, SuspiciousActivity, Opportunity, DealMemo, SmartPayment, NegotiationSession, OrderEvent, NegotiationMessage, ChatConversation, ChatMessage, FlashDeal } from '../types';

// This is the shape of our application state
interface AppState {
  users: User[];
  ads: Ad[];
  externalAds: ExternalAd[];
  settings: AppSettings;
  categories: Category[];
  provinces: Province[];
  reviews: Review[];
  notifications: Notification[];
  rfqs: RequestForQuotation[];
  offers: Offer[];
  featureFlags: FeatureFlag[];
  auctions: Auction[];
  personalizedOffers: PersonalizedOffer[];
  stockWatches: StockWatch[];
  marketBriefs: MarketBrief[];
  systemHealth: SystemHealth;
  suspiciousActivities: SuspiciousActivity[];
  opportunities: Opportunity[];
  dealMemos: DealMemo[];
  smartPayments: SmartPayment[];
  negotiationSessions: NegotiationSession[];
  conversations: ChatConversation[];
  messages: ChatMessage[];
}

// Initial state with empty data, to be filled from Supabase
const initialAppState: AppState = {
  users: [],
  ads: [],
  externalAds: [],
  settings: {
    googleAdsEnabled: false,
    featuredAdPrice: 15000,
    announcementText: '',
    announcementType: 'info',
    isAnnouncementActive: false,
    maintenanceMode: false,
    zainCashNumber: '',
    asiaPayNumber: '',
    charityProgramDescription: '',
    smallProjectsProgramDescription: ''
  },
  categories: [],
  provinces: [],
  reviews: [],
  notifications: [],
  rfqs: [],
  offers: [],
  featureFlags: [],
  auctions: [],
  personalizedOffers: [],
  stockWatches: [],
  marketBriefs: [],
  systemHealth: { apiStatus: 'operational', databaseStatus: 'operational', aiServiceStatus: 'operational' },
  suspiciousActivities: [],
  opportunities: [],
  dealMemos: [],
  smartPayments: [],
  negotiationSessions: [],
  conversations: [],
  messages: [],
};

interface AdminContextType {
  // Main Data Slices (Read-only)
  users: User[];
  ads: Ad[];
  externalAds: ExternalAd[];
  settings: AppSettings;
  categories: Category[];
  provinces: Province[];
  reviews: Review[];
  notifications: Notification[];
  rfqs: RequestForQuotation[];
  offers: Offer[];
  featureFlags: FeatureFlag[];
  auctions: Auction[];
  personalizedOffers: PersonalizedOffer[];
  stockWatches: StockWatch[];
  marketBriefs: MarketBrief[];
  systemHealth: SystemHealth;
  suspiciousActivities: SuspiciousActivity[];
  opportunities: Opportunity[];
  dealMemos: DealMemo[];
  smartPayments: SmartPayment[];
  negotiationSessions: NegotiationSession[];
  conversations: ChatConversation[];
  messages: ChatMessage[];
  isDataLoaded: boolean;
  
  // Ad Functions
  getAdById: (adId: string) => Ad | undefined;
  addAd: (newAd: Omit<Ad, 'id' | 'userId' | 'featured' | 'status' | 'views' | 'saves'>, userId: string) => Promise<Ad>;
  updateAd: (adId: string, updatedData: Partial<Ad>) => Promise<void>;
  deleteAd: (adId: string) => Promise<void>;
  toggleAdFeature: (adId: string) => Promise<void>;
  updateAdStatus: (adId: string, status: 'approved' | 'rejected', rejectionReason?: string) => Promise<void>;
  createAuction: (adId: string, startPrice: number, durationHours: number) => Promise<void>;
  createPersonalizedOffer: (adId: string, discountPercentage: number, sellerId: string) => Promise<void>;
  trackAdView: (adId: string) => Promise<void>; 
  updateAdSaves: (adId: string, isFavoriting: boolean) => Promise<void>;
  createFlashDeal: (adId: string, dealPrice: string, durationHours: number) => Promise<void>;
  endFlashDeal: (adId: string) => Promise<void>;
  createStockWatch: (watchData: Omit<StockWatch, 'id' | 'userId'>, userId: string) => Promise<void>;
  getStockWatchesForUser: (userId: string) => StockWatch[];
  deleteStockWatch: (watchId: string) => Promise<void>;
  featureAdForFree: (adId: string) => Promise<void>;

  // User Functions
  updateUser: (userId: string, updatedData: Partial<User>) => Promise<void>;
  updateUserRole: (userId: string, role: UserRole) => Promise<void>;
  toggleUserBan: (userId: string) => Promise<void>;
  toggleUserVerification: (userId: string) => Promise<void>;
  deleteUser: (userId: string) => Promise<void>;
  addUser: (user: Omit<User, 'id'>) => Promise<User>;
  
  // Settings & External Ads
  updateSettings: (newSettings: Partial<AppSettings>) => Promise<void>;
  addExternalAd: (ad: Omit<ExternalAd, 'id'>) => Promise<void>;
  updateExternalAd: (ad: ExternalAd) => Promise<void>;
  
  // Dynamic Content
  addCategory: (name: string) => Promise<void>;
  deleteCategory: (id: string) => Promise<void>;
  addSubcategory: (categoryId: string, name: string) => Promise<void>;
  deleteSubcategory: (categoryId: string, name: string) => Promise<void>;
  addProvince: (name: string) => Promise<void>;
  deleteProvince: (id: string) => Promise<void>;
  
  // Review Functions
  getReviewsForSeller: (sellerId: string) => Review[];
  deleteReview: (reviewId: string) => Promise<void>;
  calculateAverageRating: (sellerId: string) => { average: number; count: number };
  addReview: (reviewData: Omit<Review, 'id'|'timestamp'>) => Promise<void>;

  // Notification Functions
  markAsRead: (notificationId: string) => Promise<void>;
  markAllAsRead: (userId: string) => Promise<void>;
  clearAllNotifications: (userId: string) => Promise<void>;
  createNotification: (notification: Omit<Notification, 'id' | 'timestamp' | 'isRead'>) => Promise<void>;
  unreadNotificationCount: (userId: string) => number;
  
  // Feature Flag Functions
  toggleFeatureFlag: (featureId: string) => Promise<void>;
  
  // Stats
  stats: any;

  // Smart Advisor Functions
  getPricingAnalysis: (productName: string, userId: string) => { myPrice: number | null; competitorPrices: number[] };
  getDemandHotspots: () => { province: string; count: number }[];
  getProductOpportunities: () => { productName: string; demand: number; supply: number }[];
  getOpportunitiesForUser: (user: User) => Opportunity[];
  
  // Auction Functions
  getAuctionById: (auctionId: string) => Auction | undefined;
  placeBid: (auctionId: string, amount: number, userId: string) => Promise<void>;

  // RFQ Functions
  addRfq: (rfqData: Omit<RequestForQuotation, 'id' | 'userId' | 'timestamp' | 'status'>, userId: string) => Promise<void>;
  addOfferToRfq: (offerData: Omit<Offer, 'id' | 'sellerId' | 'timestamp'>, sellerId: string) => Promise<void>;
  getOffersForRfq: (rfqId: string) => Offer[];
  
  // Market Brief
  addMarketBrief: (brief: Omit<MarketBrief, 'id'>) => Promise<void>;
  addDealMemo: (conversationId: string, dealDetails: Omit<DealMemo, 'id'|'conversationId'|'status'|'approverIds'|'timestamp'>, creatorId: string) => Promise<DealMemo>;
  updateDealMemo: (memoId: string, updatedData: Partial<DealMemo>) => Promise<void>;

  // AI Tools
  scanForSuspiciousActivity: () => Promise<void>;

  // Smart SafePay
  getSmartPaymentByMemoId: (memoId: string) => SmartPayment | undefined;
  initiateSmartPayment: (memoId: string, buyerId: string, sellerId: string, amount: number) => Promise<SmartPayment>;
  updateSmartPaymentStatus: (paymentId: string, status: SmartPayment['status'], description?: string) => Promise<void>;
  addShippingInfoToPayment: (paymentId: string, shippingInfo: { company: string; trackingNumber: string; }) => Promise<void>;
  raiseDispute: (paymentId: string, reason: string) => Promise<void>;
  resolveDispute: (paymentId: string, resolution: 'refund' | 'payout') => Promise<void>;

  // Partnership Score
  calculatePartnershipScore: (userId1: string, userId2: string) => { dealCount: number; avgRating: number; };
  
  // Referral System
  grantReferralReward: (userId: string) => Promise<void>;
  applyFreeFeature: (adId: string, userId: string) => Promise<void>;
  
  // Negotiation Sessions
  addNegotiationSession: (sessionData: Omit<NegotiationSession, 'id'>) => Promise<NegotiationSession>;
  addNegotiationMessage: (sessionId: string, message: NegotiationMessage) => Promise<void>;

  // Chat
  setMessages: React.Dispatch<React.SetStateAction<ChatMessage[]>>;
  setConversations: React.Dispatch<React.SetStateAction<ChatConversation[]>>;
}

const AdminContext = createContext<AdminContextType | undefined>(undefined);

export const AdminProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
    const [state, setState] = useState<AppState>(initialAppState);
    const [isDataLoaded, setIsDataLoaded] = useState(false);

    const fetchInitialData = useCallback(async () => {
        console.log("Fetching initial data from Supabase...");
        try {
            const results = await Promise.all([
                supabase.from('users').select('*'), supabase.from('ads').select('*'),
                supabase.from('categories').select('*'), supabase.from('provinces').select('*'),
                supabase.from('reviews').select('*'), supabase.from('notifications').select('*'),
                supabase.from('settings').select('*').limit(1).single(), supabase.from('external_ads').select('*'),
                supabase.from('rfqs').select('*'), supabase.from('offers').select('*'),
                supabase.from('feature_flags').select('*'), supabase.from('auctions').select('*'),
                supabase.from('personalized_offers').select('*'), supabase.from('stock_watches').select('*'),
                supabase.from('market_briefs').select('*'), supabase.from('suspicious_activities').select('*'),
                supabase.from('opportunities').select('*'), supabase.from('deal_memos').select('*'),
                supabase.from('smart_payments').select('*'), supabase.from('negotiation_sessions').select('*'),
                supabase.from('conversations').select('*'), supabase.from('messages').select('*'),
            ]);
            const [
                users, ads, categories, provinces, reviews, notifications, settings, externalAds,
                rfqs, offers, featureFlags, auctions, personalizedOffers, stockWatches, marketBriefs,
                suspiciousActivities, opportunities, dealMemos, smartPayments, negotiationSessions,
                conversations, messages
            ] = results.map(res => res.data);
            
            const errors = results.map(res => res.error).filter(Boolean);
            if (errors.length > 0) {
                errors.forEach(error => console.error("Supabase fetch error:", error?.message));
                throw new Error('Failed to fetch some initial data from Supabase.');
            }
            
            setState(prev => ({
                ...prev,
                users: (users as User[]) || [], ads: (ads as Ad[]) || [], categories: (categories as Category[]) || [],
                provinces: (provinces as Province[]) || [], reviews: (reviews as Review[]) || [],
                notifications: (notifications as Notification[]) || [], settings: (settings as AppSettings) || prev.settings,
                externalAds: (externalAds as ExternalAd[]) || [], rfqs: (rfqs as RequestForQuotation[]) || [],
                offers: (offers as Offer[]) || [], featureFlags: (featureFlags as FeatureFlag[]) || [],
                auctions: (auctions as Auction[]) || [], personalizedOffers: (personalizedOffers as PersonalizedOffer[]) || [],
                stockWatches: (stockWatches as StockWatch[]) || [], marketBriefs: (marketBriefs as MarketBrief[]) || [],
                suspiciousActivities: (suspiciousActivities as SuspiciousActivity[]) || [], opportunities: (opportunities as Opportunity[]) || [],
                dealMemos: (dealMemos as DealMemo[]) || [], smartPayments: (smartPayments as SmartPayment[]) || [],
                negotiationSessions: (negotiationSessions as NegotiationSession[]) || [], conversations: (conversations as ChatConversation[]) || [],
                messages: (messages as ChatMessage[]) || [],
            }));
        } catch (error) {
            console.error("Error loading data from Supabase:", error);
        } finally {
            setIsDataLoaded(true);
            console.log("Initial data fetch complete.");
        }
    }, []);

    useEffect(() => {
        fetchInitialData();
    }, [fetchInitialData]);

    const handleError = (error: any, operation: string) => {
        console.error(`Supabase error during ${operation}:`, error);
        throw error;
    }

    const getAdById = useCallback((adId: string) => state.ads.find(ad => ad.id === adId), [state.ads]);

    const addAd = useCallback(async (newAdData: Omit<Ad, 'id' | 'userId' | 'featured' | 'status' | 'views' | 'saves'>, userId: string): Promise<Ad> => {
        const { data, error } = await supabase.from('ads').insert({ ...newAdData, userId, status: 'pending', views: 0, saves: 0, featured: false }).select().single();
        if (error) handleError(error, 'addAd');
        setState(prev => ({ ...prev, ads: [...prev.ads, data] }));
        return data;
    }, []);

    const updateAd = useCallback(async (adId: string, updatedData: Partial<Ad>) => {
        const { data, error } = await supabase.from('ads').update(updatedData).eq('id', adId).select().single();
        if (error) handleError(error, 'updateAd');
        setState(prev => ({ ...prev, ads: prev.ads.map(ad => ad.id === adId ? data : ad) }));
    }, []);

    const deleteAd = useCallback(async (adId: string) => {
        const { error } = await supabase.from('ads').delete().eq('id', adId);
        if (error) handleError(error, 'deleteAd');
        setState(prev => ({ ...prev, ads: prev.ads.filter(ad => ad.id !== adId) }));
    }, []);
    
    const trackAdView = useCallback(async (adId: string) => {
        setState(prev => ({ ...prev, ads: prev.ads.map(a => a.id === adId ? { ...a, views: (a.views || 0) + 1 } : a) }));
        const { error } = await supabase.rpc('increment_ad_views', { ad_id: adId });
        if (error) console.error("Error incrementing view count:", error);
    }, []);

    const updateAdSaves = useCallback(async (adId: string, isFavoriting: boolean) => {
        const change = isFavoriting ? 1 : -1;
        setState(prev => ({ ...prev, ads: prev.ads.map(a => a.id === adId ? { ...a, saves: Math.max(0, (a.saves || 0) + change) } : a) }));
        const { error } = await supabase.rpc('increment_ad_saves', { ad_id: adId, increment_value: change });
        if (error) console.error("Error updating save count:", error);
    }, []);
    
    const addUser = useCallback(async (userData: Omit<User, 'id'>): Promise<User> => {
        const { data, error } = await supabase.from('users').insert(userData).select().single();
        if (error) handleError(error, 'addUser');
        setState(prev => ({ ...prev, users: [...prev.users, data] }));
        return data;
    }, []);

    const updateUser = useCallback(async (userId: string, updatedData: Partial<User>) => {
        const { data, error } = await supabase.from('users').update(updatedData).eq('id', userId).select().single();
        if (error) handleError(error, 'updateUser');
        setState(prev => ({ ...prev, users: prev.users.map(u => u.id === userId ? data : u) }));
    }, []);

    const deleteUser = useCallback(async (userId: string) => {
        const { error } = await supabase.from('users').delete().eq('id', userId);
        if (error) handleError(error, 'deleteUser');
        setState(prev => ({ ...prev, users: prev.users.filter(u => u.id !== userId) }));
    }, []);

    const addReview = useCallback(async (reviewData: Omit<Review, 'id' | 'timestamp'>) => {
        const { data, error } = await supabase.from('reviews').insert({ ...reviewData, timestamp: new Date().toISOString() }).select().single();
        if (error) handleError(error, 'addReview');
        setState(prev => ({ ...prev, reviews: [...prev.reviews, data] }));
    }, []);

    const deleteReview = useCallback(async (reviewId: string) => {
        const { error } = await supabase.from('reviews').delete().eq('id', reviewId);
        if (error) handleError(error, 'deleteReview');
        setState(prev => ({ ...prev, reviews: prev.reviews.filter(r => r.id !== reviewId) }));
    }, []);

    const createNotification = useCallback(async (notificationData: Omit<Notification, 'id' | 'timestamp' | 'isRead'>) => {
        const { data, error } = await supabase.from('notifications').insert({ ...notificationData, isRead: false, timestamp: new Date().toISOString() }).select().single();
        if (error) handleError(error, 'createNotification');
        setState(prev => ({ ...prev, notifications: [...prev.notifications, data] }));
    }, []);

    const updateAdStatus = useCallback(async (adId: string, status: 'approved' | 'rejected', rejectionReason?: string) => {
        await updateAd(adId, { status, rejectionReason: rejectionReason || undefined });
        const ad = state.ads.find(a => a.id === adId);
        if (ad) {
            createNotification({ userId: ad.userId, type: status === 'approved' ? 'ad_approved' : 'ad_rejected', text: status === 'approved' ? `تمت الموافقة على إعلانك "${ad.title}"` : `تم رفض إعلانك "${ad.title}". السبب: ${rejectionReason}`, link: `/ad/${ad.id}`, relatedId: ad.id });
        }
    }, [updateAd, state.ads, createNotification]);

    const updateUserRole = useCallback(async (userId: string, role: UserRole) => updateUser(userId, { role }), [updateUser]);

    const toggleUserBan = useCallback(async (userId: string) => {
        const user = state.users.find(u => u.id === userId);
        if (user) await updateUser(userId, { banned: !user.banned });
    }, [state.users, updateUser]);

    const toggleUserVerification = useCallback(async (userId: string) => {
        const user = state.users.find(u => u.id === userId);
        if (user) await updateUser(userId, { isVerified: !user.isVerified });
    }, [state.users, updateUser]);
    
    const toggleAdFeature = useCallback(async (adId: string) => {
        const ad = state.ads.find(a => a.id === adId);
        if (ad) {
            const featuredUntil = !ad.featured ? new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString() : undefined;
            await updateAd(adId, { featured: !ad.featured, featuredUntil });
        }
    }, [state.ads, updateAd]);

    const createAuction = useCallback(async (adId: string, startPrice: number, durationHours: number) => {
        const endTime = new Date(Date.now() + durationHours * 60 * 60 * 1000).toISOString();
        const { data, error } = await supabase.from('auctions').insert({ adId, startTime: new Date().toISOString(), endTime, startPrice, currentPrice: startPrice, bids: [], status: 'active' }).select().single();
        if (error) handleError(error, 'createAuction');
        setState(prev => ({ ...prev, auctions: [...prev.auctions, data] }));
        await updateAd(adId, { auctionId: data.id });
    }, [updateAd]);

    const createPersonalizedOffer = useCallback(async (adId: string, discountPercentage: number, sellerId: string) => {
        const { data, error } = await supabase.from('personalized_offers').insert({ adId, discountPercentage, sellerId, timestamp: new Date().toISOString() }).select().single();
        if (error) handleError(error, 'createPersonalizedOffer');
        setState(prev => ({ ...prev, personalizedOffers: [...prev.personalizedOffers, data] }));
    }, []);

    const createFlashDeal = useCallback(async (adId: string, dealPrice: string, durationHours: number) => {
        const flashDeal: FlashDeal = { isActive: true, dealPrice, endTime: new Date(Date.now() + durationHours * 60 * 60 * 1000).toISOString() };
        await updateAd(adId, { flashDeal });
    }, [updateAd]);

    const endFlashDeal = useCallback(async (adId: string) => {
        const ad = state.ads.find(a => a.id === adId);
        if (ad?.flashDeal) {
            await updateAd(adId, { flashDeal: { ...ad.flashDeal, isActive: false } });
        }
    }, [state.ads, updateAd]);

    const createStockWatch = useCallback(async (watchData: Omit<StockWatch, 'id' | 'userId'>, userId: string) => {
        const { data, error } = await supabase.from('stock_watches').insert({ ...watchData, userId }).select().single();
        if (error) handleError(error, 'createStockWatch');
        setState(prev => ({ ...prev, stockWatches: [...prev.stockWatches, data] }));
    }, []);

    const deleteStockWatch = useCallback(async (watchId: string) => {
        const { error } = await supabase.from('stock_watches').delete().eq('id', watchId);
        if (error) handleError(error, 'deleteStockWatch');
        setState(prev => ({ ...prev, stockWatches: prev.stockWatches.filter(sw => sw.id !== watchId) }));
    }, []);

    const featureAdForFree = useCallback(async (adId: string) => {
        const featuredUntil = new Date(Date.now() + 2 * 24 * 60 * 60 * 1000).toISOString();
        await updateAd(adId, { featured: true, featuredUntil });
    }, [updateAd]);

    const updateSettings = useCallback(async (newSettings: Partial<AppSettings>) => {
        const { data, error } = await supabase.from('settings').update(newSettings).eq('id', 1).select().single();
        if (error) handleError(error, 'updateSettings');
        setState(prev => ({ ...prev, settings: data }));
    }, []);

    const addExternalAd = useCallback(async (ad: Omit<ExternalAd, 'id'>) => {
        const { data, error } = await supabase.from('external_ads').insert(ad).select().single();
        if (error) handleError(error, 'addExternalAd');
        setState(prev => ({ ...prev, externalAds: [...prev.externalAds, data] }));
    }, []);

    const updateExternalAd = useCallback(async (ad: ExternalAd) => {
        const { data, error } = await supabase.from('external_ads').update(ad).eq('id', ad.id).select().single();
        if (error) handleError(error, 'updateExternalAd');
        setState(prev => ({ ...prev, externalAds: prev.externalAds.map(a => a.id === ad.id ? data : a) }));
    }, []);

    const addCategory = useCallback(async (name: string) => {
        const { data, error } = await supabase.from('categories').insert({ name, subcategories: [] }).select().single();
        if (error) handleError(error, 'addCategory');
        setState(prev => ({ ...prev, categories: [...prev.categories, data] }));
    }, []);

    const deleteCategory = useCallback(async (id: string) => {
        const { error } = await supabase.from('categories').delete().eq('id', id);
        if (error) handleError(error, 'deleteCategory');
        setState(prev => ({ ...prev, categories: prev.categories.filter(c => c.id !== id) }));
    }, []);

    const addSubcategory = useCallback(async (categoryId: string, name: string) => {
        const category = state.categories.find(c => c.id === categoryId);
        if (category) {
            const newSubcategories = [...category.subcategories, name];
            const { data, error } = await supabase.from('categories').update({ subcategories: newSubcategories }).eq('id', categoryId).select().single();
            if (error) handleError(error, 'addSubcategory');
            setState(prev => ({ ...prev, categories: prev.categories.map(c => c.id === categoryId ? data : c) }));
        }
    }, [state.categories]);

    const deleteSubcategory = useCallback(async (categoryId: string, name: string) => {
        const category = state.categories.find(c => c.id === categoryId);
        if (category) {
            const newSubcategories = category.subcategories.filter(s => s !== name);
            const { data, error } = await supabase.from('categories').update({ subcategories: newSubcategories }).eq('id', categoryId).select().single();
            if (error) handleError(error, 'deleteSubcategory');
            setState(prev => ({ ...prev, categories: prev.categories.map(c => c.id === categoryId ? data : c) }));
        }
    }, [state.categories]);

    const addProvince = useCallback(async (name: string) => {
        const { data, error } = await supabase.from('provinces').insert({ name }).select().single();
        if (error) handleError(error, 'addProvince');
        setState(prev => ({ ...prev, provinces: [...prev.provinces, data] }));
    }, []);

    const deleteProvince = useCallback(async (id: string) => {
        const { error } = await supabase.from('provinces').delete().eq('id', id);
        if (error) handleError(error, 'deleteProvince');
        setState(prev => ({ ...prev, provinces: prev.provinces.filter(p => p.id !== id) }));
    }, []);

    const markAsRead = useCallback(async (notificationId: string) => {
        const { data, error } = await supabase.from('notifications').update({ isRead: true }).eq('id', notificationId).select().single();
        if (error) handleError(error, 'markAsRead');
        setState(prev => ({ ...prev, notifications: prev.notifications.map(n => n.id === notificationId ? data : n) }));
    }, []);

    const markAllAsRead = useCallback(async (userId: string) => {
        const { data, error } = await supabase.from('notifications').update({ isRead: true }).eq('userId', userId).select();
        if (error) handleError(error, 'markAllAsRead');
        setState(prev => ({ ...prev, notifications: prev.notifications.map(n => n.userId === userId ? { ...n, isRead: true } : n) }));
    }, []);

    const clearAllNotifications = useCallback(async (userId: string) => {
        const { error } = await supabase.from('notifications').delete().eq('userId', userId);
        if (error) handleError(error, 'clearAllNotifications');
        setState(prev => ({ ...prev, notifications: prev.notifications.filter(n => n.userId !== userId) }));
    }, []);
    
    const toggleFeatureFlag = useCallback(async (featureId: string) => {
        const feature = state.featureFlags.find(f => f.id === featureId);
        if (feature) {
            const { data, error } = await supabase.from('feature_flags').update({ isEnabled: !feature.isEnabled }).eq('id', featureId).select().single();
            if (error) handleError(error, 'toggleFeatureFlag');
            setState(prev => ({ ...prev, featureFlags: prev.featureFlags.map(f => f.id === featureId ? data : f) }));
        }
    }, [state.featureFlags]);
    
    const placeBid = useCallback(async (auctionId: string, amount: number, userId: string) => {
        const auction = state.auctions.find(a => a.id === auctionId);
        if (auction && amount > auction.currentPrice) {
            const newBid: Bid = { userId, amount, timestamp: new Date().toISOString() };
            const newBids = [...auction.bids, newBid];
            await updateAd(auction.adId, { price: `يبدأ من ${amount.toLocaleString()} د.ع`});
            const { data, error } = await supabase.from('auctions').update({ bids: newBids, currentPrice: amount }).eq('id', auctionId).select().single();
            if (error) handleError(error, 'placeBid');
            setState(prev => ({ ...prev, auctions: prev.auctions.map(a => a.id === auctionId ? data : a) }));
        } else {
            throw new Error("المزايدة يجب أن تكون أعلى من السعر الحالي.");
        }
    }, [state.auctions, updateAd]);

    const addRfq = useCallback(async (rfqData: Omit<RequestForQuotation, 'id' | 'userId' | 'timestamp' | 'status'>, userId: string) => {
        const { data, error } = await supabase.from('rfqs').insert({ ...rfqData, userId, timestamp: new Date().toISOString(), status: 'open' }).select().single();
        if (error) handleError(error, 'addRfq');
        setState(prev => ({ ...prev, rfqs: [...prev.rfqs, data] }));
    }, []);

    const addOfferToRfq = useCallback(async (offerData: Omit<Offer, 'id' | 'sellerId' | 'timestamp'>, sellerId: string) => {
        const { data, error } = await supabase.from('offers').insert({ ...offerData, sellerId, timestamp: new Date().toISOString() }).select().single();
        if (error) handleError(error, 'addOfferToRfq');
        setState(prev => ({ ...prev, offers: [...prev.offers, data] }));
    }, []);
    
    const addMarketBrief = useCallback(async (brief: Omit<MarketBrief, 'id'>) => {
        const { data, error } = await supabase.from('market_briefs').insert(brief).select().single();
        if(error) handleError(error, 'addMarketBrief');
        setState(prev => ({ ...prev, marketBriefs: [...prev.marketBriefs, data]}));
    }, []);
    
    const addDealMemo = useCallback(async (conversationId: string, dealDetails: Omit<DealMemo, 'id'|'conversationId'|'status'|'approverIds'|'timestamp'>, creatorId: string) => {
        const { data, error } = await supabase.from('deal_memos').insert({ ...dealDetails, conversationId, status: 'pending', approverIds: [creatorId], timestamp: new Date().toISOString() }).select().single();
        if(error) handleError(error, 'addDealMemo');
        setState(prev => ({ ...prev, dealMemos: [...prev.dealMemos, data]}));
        return data;
    }, []);
    
    const updateDealMemo = useCallback(async (memoId: string, updatedData: Partial<DealMemo>) => {
        const memo = state.dealMemos.find(m => m.id === memoId);
        if(!memo) return;
        const newApprovers = [...memo.approverIds, ...(updatedData.approverIds || [])];
        const status = newApprovers.length >= 2 ? 'approved' : 'pending';
        const { data, error } = await supabase.from('deal_memos').update({ ...updatedData, approverIds: newApprovers, status }).eq('id', memoId).select().single();
        if (error) handleError(error, 'updateDealMemo');
        setState(prev => ({ ...prev, dealMemos: prev.dealMemos.map(m => m.id === memoId ? data : m) }));
    }, [state.dealMemos]);
    
    const initiateSmartPayment = useCallback(async (memoId: string, buyerId: string, sellerId: string, amount: number) => {
        const initialEvent: OrderEvent = { timestamp: new Date().toISOString(), status: 'pending_deposit', description: 'تم إنشاء الدفعة الآمنة.' };
        const { data, error } = await supabase.from('smart_payments').insert({ memoId, buyerId, sellerId, amount, status: 'pending_deposit', orderHistory: [initialEvent] }).select().single();
        if (error) handleError(error, 'initiateSmartPayment');
        setState(prev => ({ ...prev, smartPayments: [...prev.smartPayments, data] }));
        return data;
    }, []);

    const updateSmartPaymentStatus = useCallback(async (paymentId: string, status: SmartPayment['status'], description?: string) => {
        const payment = state.smartPayments.find(p => p.id === paymentId);
        if (payment) {
            const newEvent: OrderEvent = { timestamp: new Date().toISOString(), status, description: description || `تم تحديث الحالة إلى ${status}` };
            const { data, error } = await supabase.from('smart_payments').update({ status, orderHistory: [...payment.orderHistory, newEvent] }).eq('id', paymentId).select().single();
            if(error) handleError(error, 'updateSmartPaymentStatus');
            setState(prev => ({ ...prev, smartPayments: prev.smartPayments.map(p => p.id === paymentId ? data : p)}));
        }
    }, [state.smartPayments]);
    
    const addShippingInfoToPayment = useCallback(async (paymentId: string, shippingInfo: { company: string; trackingNumber: string; }) => {
        await updateSmartPaymentStatus(paymentId, 'shipped', `تم الشحن عبر ${shippingInfo.company}.`);
        const { data, error } = await supabase.from('smart_payments').update({ shippingInfo }).eq('id', paymentId).select().single();
        if(error) handleError(error, 'addShippingInfo');
        setState(prev => ({ ...prev, smartPayments: prev.smartPayments.map(p => p.id === paymentId ? {...p, ...data} : p)}));
    }, [updateSmartPaymentStatus]);
    
    const raiseDispute = useCallback(async (paymentId: string, reason: string) => {
        await updateSmartPaymentStatus(paymentId, 'disputed', `تم فتح نزاع: ${reason}`);
    }, [updateSmartPaymentStatus]);

    const resolveDispute = useCallback(async (paymentId: string, resolution: 'refund' | 'payout') => {
        const description = resolution === 'refund' ? 'تم حل النزاع لصالح المشتري.' : 'تم حل النزاع لصالح البائع.';
        await updateSmartPaymentStatus(paymentId, 'completed', description);
    }, [updateSmartPaymentStatus]);

    const grantReferralReward = useCallback(async (userId: string) => {
        const user = state.users.find(u => u.id === userId);
        if(user) {
            await updateUser(userId, { pendingReferralReward: false, availableFeatureRewards: (user.availableFeatureRewards || 0) + 1});
        }
    }, [state.users, updateUser]);
    
    const applyFreeFeature = useCallback(async (adId: string, userId: string) => {
        const user = state.users.find(u => u.id === userId);
        if (user && user.availableFeatureRewards > 0) {
            await updateUser(userId, { availableFeatureRewards: user.availableFeatureRewards - 1 });
            await featureAdForFree(adId);
        } else {
            throw new Error("لا توجد مكافآت تمييز متاحة.");
        }
    }, [state.users, updateUser, featureAdForFree]);

    const addNegotiationSession = useCallback(async (sessionData: Omit<NegotiationSession, 'id'>) => {
        const { data, error } = await supabase.from('negotiation_sessions').insert(sessionData).select().single();
        if(error) handleError(error, 'addNegotiationSession');
        setState(prev => ({...prev, negotiationSessions: [...prev.negotiationSessions, data]}));
        return data;
    }, []);

    const addNegotiationMessage = useCallback(async (sessionId: string, message: NegotiationMessage) => {
        const session = state.negotiationSessions.find(s => s.id === sessionId);
        if (session) {
            const { data, error } = await supabase.from('negotiation_sessions').update({ history: [...session.history, message] }).eq('id', sessionId).select().single();
            if(error) handleError(error, 'addNegotiationMessage');
            setState(prev => ({ ...prev, negotiationSessions: prev.negotiationSessions.map(s => s.id === sessionId ? data : s)}));
        }
    }, [state.negotiationSessions]);

    const scanForSuspiciousActivity = useCallback(async () => {
        // This is a mock implementation. A real one would run complex queries or AI models.
        const newActivity: SuspiciousActivity = {
            id: `susp_${Date.now()}`,
            description: 'فحص يدوي: تم رصد تغييرات سريعة في الأسعار لإعلان معين.',
            relatedAdId: state.ads[0]?.id,
            timestamp: new Date().toISOString(),
            priority: 'low',
        };
        const { data, error } = await supabase.from('suspicious_activities').insert(newActivity).select().single();
        if(error) handleError(error, 'scanForSuspiciousActivity');
        setState(prev => ({ ...prev, suspiciousActivities: [...prev.suspiciousActivities, data] }));
    }, [state.ads]);
    
    // Synchronous functions
    const getStockWatchesForUser = useCallback((userId: string) => state.stockWatches.filter(sw => sw.userId === userId), [state.stockWatches]);
    const getReviewsForSeller = useCallback((sellerId: string) => state.reviews.filter(r => r.sellerId === sellerId), [state.reviews]);
    const calculateAverageRating = useCallback((sellerId: string) => {
        const sellerReviews = state.reviews.filter(r => r.sellerId === sellerId);
        if (sellerReviews.length === 0) return { average: 0, count: 0 };
        const total = sellerReviews.reduce((sum, r) => sum + r.rating, 0);
        return { average: total / sellerReviews.length, count: sellerReviews.length };
    }, [state.reviews]);
    const unreadNotificationCount = useCallback((userId: string) => state.notifications.filter(n => n.userId === userId && !n.isRead).length, [state.notifications]);
    const getAuctionById = useCallback((auctionId: string) => state.auctions.find(a => a.id === auctionId), [state.auctions]);
    const getOffersForRfq = useCallback((rfqId: string) => state.offers.filter(o => o.rfqId === rfqId), [state.offers]);
    const getSmartPaymentByMemoId = useCallback((memoId: string) => state.smartPayments.find(p => p.memoId === memoId), [state.smartPayments]);
    const calculatePartnershipScore = useCallback((userId1: string, userId2: string) => {
        const dealCount = state.smartPayments.filter(p => p.status === 'completed' && ((p.buyerId === userId1 && p.sellerId === userId2) || (p.buyerId === userId2 && p.sellerId === userId1))).length;
        const reviews1to2 = state.reviews.filter(r => r.reviewerId === userId1 && r.sellerId === userId2);
        const reviews2to1 = state.reviews.filter(r => r.reviewerId === userId2 && r.sellerId === userId1);
        const allReviews = [...reviews1to2, ...reviews2to1];
        const avgRating = allReviews.length > 0 ? allReviews.reduce((sum, r) => sum + r.rating, 0) / allReviews.length : 0;
        return { dealCount, avgRating };
    }, [state.smartPayments, state.reviews]);
    const getPricingAnalysis = useCallback((productName: string, userId: string) => {
        const myAd = state.ads.find(ad => ad.userId === userId && ad.title.includes(productName));
        const myPrice = myAd ? parseFloat(myAd.price.replace(/[^0-9]/g, '')) : null;
        const competitorPrices = state.ads.filter(ad => ad.userId !== userId && ad.title.includes(productName)).map(ad => parseFloat(ad.price.replace(/[^0-9]/g, '')));
        return { myPrice, competitorPrices };
    }, [state.ads]);
    const getDemandHotspots = useCallback(() => {
        const counts = state.rfqs.reduce((acc, rfq) => {
            acc[rfq.province] = (acc[rfq.province] || 0) + 1;
            return acc;
        }, {} as Record<string, number>);
        return Object.entries(counts).map(([province, count]) => ({ province, count })).sort((a, b) => b.count - a.count);
    }, [state.rfqs]);
    const getProductOpportunities = useCallback(() => {
        const demand = state.rfqs.reduce((acc, rfq) => { acc[rfq.category] = (acc[rfq.category] || 0) + 1; return acc; }, {} as Record<string, number>);
        const supply = state.ads.reduce((acc, ad) => { acc[ad.category] = (acc[ad.category] || 0) + 1; return acc; }, {} as Record<string, number>);
        return Object.keys(demand).filter(cat => (demand[cat] || 0) > (supply[cat] || 0)).map(cat => ({ productName: cat, demand: demand[cat], supply: supply[cat] || 0 }));
    }, [state.rfqs, state.ads]);
    const getOpportunitiesForUser = useCallback((user: User): Opportunity[] => {
        const opportunities: Opportunity[] = [];
        if (user.role === 'wholesaler') {
            const myCategories = [...new Set(state.ads.filter(ad => ad.userId === user.id).map(ad => ad.category))];
            state.rfqs.forEach(rfq => {
                if (myCategories.includes(rfq.category)) {
                    opportunities.push({ id: `opp_rfq_${rfq.id}`, userId: user.id, type: 'rfq_match', title: `طلب جديد يطابق فئاتك: ${rfq.productName}`, description: `هناك طلب على ${rfq.quantity} وحدة في ${rfq.province}.`, relatedId: rfq.id, timestamp: rfq.timestamp });
                }
            });
        }
        return opportunities.slice(0, 5);
    }, [state.ads, state.rfqs]);

    const stats = useMemo(() => {
        const featuredAds = state.ads.filter(ad => ad.featured);
        return {
            userCount: state.users.length,
            adCount: state.ads.length,
            pendingAdCount: state.ads.filter(ad => ad.status === 'pending').length,
            reviewCount: state.reviews.length,
            activeExternalAdsCount: state.externalAds.filter(ad => ad.isActive).length,
            featuredAdRevenue: featuredAds.length * state.settings.featuredAdPrice,
            totalRevenue: featuredAds.length * state.settings.featuredAdPrice, // Simplified
            activeFeatureCount: state.featureFlags.filter(f => f.isEnabled).length,
        };
    }, [state]);
    
    const setMessages = useCallback((updater: React.SetStateAction<ChatMessage[]>) => { setState(prev => ({ ...prev, messages: typeof updater === 'function' ? updater(prev.messages) : updater })); }, []);
    const setConversations = useCallback((updater: React.SetStateAction<ChatConversation[]>) => { setState(prev => ({ ...prev, conversations: typeof updater === 'function' ? updater(prev.conversations) : updater })); }, []);

    const providerValue: AdminContextType = {
        ...state, isDataLoaded, stats, getAdById, addAd, updateAd, deleteAd, trackAdView, updateAdSaves, addUser, updateUser, addReview, createNotification,
        updateAdStatus, getReviewsForSeller, calculateAverageRating, unreadNotificationCount, getAuctionById, getOffersForRfq, getSmartPaymentByMemoId,
        calculatePartnershipScore, getStockWatchesForUser, getPricingAnalysis, getDemandHotspots, getProductOpportunities, getOpportunitiesForUser,
        scanForSuspiciousActivity, deleteReview, updateUserRole, toggleUserBan, toggleUserVerification, deleteUser, toggleAdFeature, createAuction,
        createPersonalizedOffer, createFlashDeal, endFlashDeal, createStockWatch, deleteStockWatch, featureAdForFree, updateSettings, addExternalAd,
        updateExternalAd, addCategory, deleteCategory, addSubcategory, deleteSubcategory, addProvince, deleteProvince, markAsRead, markAllAsRead,
        clearAllNotifications, toggleFeatureFlag, placeBid, addRfq, addOfferToRfq, addMarketBrief, addDealMemo, updateDealMemo, initiateSmartPayment,
        updateSmartPaymentStatus, addShippingInfoToPayment, raiseDispute, resolveDispute, grantReferralReward, applyFreeFeature, addNegotiationSession,
        addNegotiationMessage, setMessages, setConversations,
    };

    return (
        <AdminContext.Provider value={providerValue}>
            {children}
        </AdminContext.Provider>
    );
};

export const useAdmin = (): AdminContextType => {
  const context = useContext(AdminContext);
  if (!context) {
    throw new Error('useAdmin must be used within an AdminProvider');
  }
  return context;
};