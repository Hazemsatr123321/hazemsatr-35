import React, { createContext, useState, useContext, ReactNode, useCallback, useEffect } from 'react';
import type { ChatConversation, ChatMessage, Ad, NegotiationSession, AdLinkDetails, DealMemo, NegotiationMessage, TextChatMessage, MessageStatus } from '../types';
import { useUser } from './UserContext';
import { useAdmin } from './AdminContext';
import { generateDealMemoFromChat } from '../services/geminiService';
import { mockConversations, mockMessages } from '../data/mockData';

interface ChatContextType {
  conversations: ChatConversation[];
  getMessagesForConversation: (conversationId: string) => ChatMessage[];
  sendMessage: (conversationId: string, text: string, type?: 'text' | 'ad_link' | 'deal_memo', details?: any) => void;
  startConversation: (otherUserId: string, ad?: Ad) => Promise<ChatConversation | null>;
  markConversationAsRead: (conversationId: string) => void;
  generateAndSendDealMemo: (conversationId: string, messages: ChatMessage[]) => Promise<void>;
  approveDealMemo: (conversationId: string, memoId: string) => void;
  unreadCount: number;

  // Negotiation Bot
  getNegotiationSession: (adId: string) => NegotiationSession | undefined;
  startNegotiation: (adId: string, sellerId: string, targetPrice: number, lowestPrice: number) => Promise<NegotiationSession>;
  sendNegotiationMessage: (sessionId: string, text: string, sender: 'bot' | 'seller') => void;
}

const ChatContext = createContext<ChatContextType | undefined>(undefined);

export const ChatProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const { currentUser } = useUser();
  const { 
      addDealMemo: adminAddDealMemo, 
      updateDealMemo: adminUpdateDealMemo,
      negotiationSessions,
      addNegotiationSession,
      addNegotiationMessage
  } = useAdmin();

  const [conversations, setConversations] = useState<ChatConversation[]>(mockConversations);
  const [messages, setMessages] = useState<ChatMessage[]>(mockMessages);
  const [unreadCount, setUnreadCount] = useState(0);
  
  useEffect(() => {
    if (!currentUser) {
      setConversations([]);
      setMessages([]);
      setUnreadCount(0);
      return;
    }

    const userConversations = mockConversations.filter(c => c.participantIds.includes(currentUser.id));
    const unread = userConversations.reduce((count, conv) => {
        if (conv.lastMessage?.senderId !== currentUser.id && conv.lastMessage?.status !== 'read') {
            return count + 1;
        }
        return count;
    }, 0);
      
    setUnreadCount(unread);
    setConversations(userConversations);
  }, [currentUser]);

  const getMessagesForConversation = useCallback((conversationId: string) => {
    return messages.filter(m => m.conversationId === conversationId).sort((a,b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
  }, [messages]);

  const sendMessage = useCallback((conversationId: string, text: string, type: 'text' | 'ad_link' | 'deal_memo' = 'text', details?: any) => {
    if (!currentUser) return;

    const newMessage: ChatMessage = {
      id: `msg_${Date.now()}`,
      conversationId,
      senderId: currentUser.id,
      timestamp: new Date().toISOString(),
      status: 'sent',
      type: type as any, // Temp cast
      text: type === 'text' ? text : '',
      adDetails: type === 'ad_link' ? details : undefined,
      memo: type === 'deal_memo' ? details : undefined,
    };
    
    setMessages(prev => [...prev, newMessage]);
    setConversations(prev => prev.map(c => c.id === conversationId ? { ...c, lastMessage: newMessage } : c));

  }, [currentUser]);

  const startConversation = useCallback(async (otherUserId: string, ad?: Ad): Promise<ChatConversation | null> => {
    if (!currentUser) return null;
    
    const sortedIds = [currentUser.id, otherUserId].sort();
    let conversation = conversations.find(c => c.participantIds.join(',') === sortedIds.join(','));

    if (conversation) {
        return conversation;
    }

    const conversationId = `conv_${Date.now()}`;
    const firstMessageText = ad ? `مرحباً، أراسلك بخصوص إعلان "${ad.title}". هل المنتج متوفر؟` : `مرحباً.`;

    const firstMessage: TextChatMessage = {
      id: `msg_${Date.now()}`,
      conversationId,
      senderId: currentUser.id,
      timestamp: new Date().toISOString(),
      status: 'sent',
      type: 'text',
      text: firstMessageText,
    };

    const newConversation: ChatConversation = {
        id: conversationId,
        participantIds: sortedIds,
        lastMessage: firstMessage
    };

    setConversations(prev => [...prev, newConversation]);
    
    if (ad) {
      sendMessage(conversationId, '', 'ad_link', {
          adId: ad.id,
          title: ad.title,
          price: ad.price,
          image: ad.images[0]
      });
    }

    sendMessage(conversationId, firstMessageText);
    
    return newConversation;
  }, [currentUser, conversations, sendMessage]);

  const markConversationAsRead = useCallback((conversationId: string) => {
    if (!currentUser) return;
    
    setConversations(prev => prev.map(c => {
        if (c.id === conversationId && c.lastMessage.senderId !== currentUser.id) {
            return { ...c, lastMessage: { ...c.lastMessage, status: 'read' } };
        }
        return c;
    }));
    // In a real app, you'd also update the message status in the messages array
  }, [currentUser]);
  
  const generateAndSendDealMemo = useCallback(async (conversationId: string, convMessages: ChatMessage[]) => {
    if (!currentUser) throw new Error("يجب تسجيل الدخول أولاً.");
    const chatHistory = convMessages
        .filter(m => m.type === 'text')
        .map(m => `${m.senderId === currentUser.id ? 'أنا' : 'الطرف الآخر'}: ${(m as TextChatMessage).text}`)
        .join('\n');

    const dealDetails = await generateDealMemoFromChat(chatHistory);
    const newMemo = await adminAddDealMemo(conversationId, dealDetails, currentUser.id);
    
    sendMessage(conversationId, '', 'deal_memo', newMemo);
  }, [currentUser, adminAddDealMemo, sendMessage]);

  const approveDealMemo = useCallback((conversationId: string, memoId: string) => {
    if (!currentUser) throw new Error("يجب تسجيل الدخول للموافقة.");
    adminUpdateDealMemo(memoId, {
      approverIds: [currentUser.id]
    });
  }, [currentUser, adminUpdateDealMemo]);


  const getNegotiationSession = useCallback((adId: string) => {
    return negotiationSessions.find(s => s.adId === adId && s.buyerId === currentUser?.id);
  }, [negotiationSessions, currentUser]);

  const startNegotiation = useCallback(async (adId: string, sellerId: string, targetPrice: number, lowestPrice: number): Promise<NegotiationSession> => {
    if (!currentUser) throw new Error("No user");
     const newSessionData: Omit<NegotiationSession, 'id'> = {
        adId,
        buyerId: currentUser.id,
        sellerId,
        status: 'active',
        history: [{
            id: `neg_msg_${Date.now()}`,
            sender: 'bot',
            text: `مرحباً، أود التفاوض على سعر هذا المنتج. هل يمكننا البدء بسعر ${targetPrice.toLocaleString()} دينار عراقي؟`,
            timestamp: new Date().toISOString()
        }],
        targetPrice,
        lowestPrice
    };
    const newSession = await addNegotiationSession(newSessionData);
    return newSession;
  }, [currentUser, addNegotiationSession]);

  const sendNegotiationMessage = useCallback((sessionId: string, text: string, sender: 'bot' | 'seller') => {
    const newMessage: NegotiationMessage = {
        id: `neg_msg_${Date.now()}`,
        sender: sender,
        text,
        timestamp: new Date().toISOString()
    };
    addNegotiationMessage(sessionId, newMessage);
  }, [addNegotiationMessage]);

  return (
    <ChatContext.Provider value={{ 
        conversations,
        getMessagesForConversation, 
        sendMessage, 
        startConversation, 
        unreadCount, 
        markConversationAsRead,
        generateAndSendDealMemo,
        approveDealMemo,
        getNegotiationSession,
        startNegotiation,
        sendNegotiationMessage
     }}>
      {children}
    </ChatContext.Provider>
  );
};

export const useChat = (): ChatContextType => {
  const context = useContext(ChatContext);
  if (!context) {
    throw new Error('useChat must be used within a ChatProvider');
  }
  return context;
};