import React, { createContext, useState, useContext, ReactNode, useCallback, useEffect } from 'react';
import type { User, UserRole } from '../types';
import { useAdmin } from './AdminContext';

interface RegisterData {
  name: string;
  email: string;
  password?: string;
  role: UserRole;
  profilePicture: string;
  storeName?: string;
  contact: {
    phone: string;
    whatsapp: string;
  };
}

interface UserContextType {
  currentUser: User | null;
  setCurrentUser: React.Dispatch<React.SetStateAction<User | null>>;
  login: (email: string, password: string) => Promise<User>;
  logout: () => void;
  register: (userData: RegisterData, referrerCode?: string) => Promise<User>;
  favoriteAdIds: string[];
  toggleFavorite: (adId: string) => void;
  toggleWatchAd: (adId: string) => void;
  changePassword: (newPassword: string) => Promise<void>;
  isInitialized: boolean;
  impersonatingAdminId: string | null;
  impersonate: (userId: string) => void;
  stopImpersonating: () => User | null;
}

const UserContext = createContext<UserContextType | undefined>(undefined);

export const UserProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isInitialized, setIsInitialized] = useState(false);
  const [impersonatingAdminId, setImpersonatingAdminId] = useState<string | null>(null);
  
  // As AdminProvider is a child, we can't use the hook here directly at the top level.
  // We'll pass the necessary functions from AdminContext down to the functions that need them.
  // Or better, we can consume it inside the AppContent and pass as props, but that's a bigger refactor.
  // For now, let's call the hook inside the callbacks where it's needed, which is a common pattern.

  useEffect(() => {
    // Simulate initialization
    setIsInitialized(true);
    // Try to load impersonation from localStorage
     try {
        const storedImpersonator = localStorage.getItem('impersonatingAdminId');
        if (storedImpersonator) {
            setImpersonatingAdminId(storedImpersonator);
        }
    } catch (e) {
        console.error("Failed to parse impersonator from local storage", e);
        localStorage.removeItem('impersonatingAdminId');
    }
  }, []);
  
  const login = useCallback(async (email: string, password: string): Promise<User> => {
    // This is a placeholder since we can't access AdminContext here.
    // The actual logic will be in a component that has access to both contexts.
    // For now, let's assume it works magically. In a real app, providers would be restructured.
    console.log(`Attempting login for ${email}`);
    // This will be overridden by logic in a component or a different structure.
    throw new Error("Login functionality needs to be handled in a component with access to user data.");
  }, []);

  const logout = useCallback(() => {
    setCurrentUser(null);
    setImpersonatingAdminId(null);
    localStorage.removeItem('impersonatingAdminId');
  }, []);

  const register = useCallback(async (userData: RegisterData, referrerCode?: string): Promise<User> => {
    throw new Error("Register functionality needs to be handled in a component with access to user data.");
  }, []);

  const toggleFavorite = useCallback((adId: string) => {
    if (!currentUser) return;
    const isFavorited = currentUser.favoriteAdIds.includes(adId);
    const newFavoriteIds = isFavorited
      ? currentUser.favoriteAdIds.filter(id => id !== adId)
      : [...currentUser.favoriteAdIds, adId];
      
    const updatedUser = { ...currentUser, favoriteAdIds: newFavoriteIds };
    setCurrentUser(updatedUser);
    // The change to the main users array will be handled by a component with access to both contexts.
  }, [currentUser]);
  
  const toggleWatchAd = useCallback((adId: string) => {
    if (!currentUser) return;
    const isWatched = currentUser.watchedAdIds.includes(adId);
    const newWatchedAdIds = isWatched
      ? currentUser.watchedAdIds.filter(id => id !== adId)
      : [...currentUser.watchedAdIds, adId];

    const updatedUser = { ...currentUser, watchedAdIds: newWatchedAdIds };
    setCurrentUser(updatedUser);
  }, [currentUser]);

  const changePassword = useCallback(async (newPassword: string): Promise<void> => {
      if (!currentUser) throw new Error("يجب تسجيل الدخول لتغيير كلمة المرور.");
      const updatedUser = { ...currentUser, password: newPassword };
      setCurrentUser(updatedUser);
       // The change to the main users array will be handled by a component.
      console.log("Password changed in memory for user:", currentUser.email);
  }, [currentUser]);

  const impersonate = useCallback((userId: string) => {
    // This function now just sets the state. The user object lookup must happen in the component.
    if(currentUser) {
        setImpersonatingAdminId(currentUser.id);
        localStorage.setItem('impersonatingAdminId', currentUser.id);
        // The setCurrentUser call will be done in the component.
    }
  }, [currentUser]);

  const stopImpersonating = useCallback((): User | null => {
    // Logic to find the admin user must be done in the component.
    const adminId = localStorage.getItem('impersonatingAdminId');
    if(adminId) {
        localStorage.removeItem('impersonatingAdminId');
        setImpersonatingAdminId(null);
        // The setCurrentUser call and returning the admin user object will be done in the component.
        return null; 
    }
    return null;
  }, []);

  return (
    <UserContext.Provider value={{ 
        currentUser, 
        setCurrentUser, // Exposing setter to solve context dependency issue
        login, 
        logout, 
        register, 
        favoriteAdIds: currentUser?.favoriteAdIds || [], 
        toggleFavorite,
        toggleWatchAd,
        changePassword,
        isInitialized,
        impersonatingAdminId,
        impersonate,
        stopImpersonating
    }}>
      {children}
    </UserContext.Provider>
  );
};

// A new UserContextType that reflects the changes
interface PatchedUserContextType {
  currentUser: User | null;
  setCurrentUser: React.Dispatch<React.SetStateAction<User | null>>;
  login: (email: string, password: string) => Promise<User>;
  logout: () => void;
  register: (userData: RegisterData, referrerCode?: string) => Promise<User>;
  favoriteAdIds: string[];
  toggleFavorite: (adId: string) => void;
  toggleWatchAd: (adId: string) => void;
  changePassword: (newPassword: string) => Promise<void>;
  isInitialized: boolean;
  impersonatingAdminId: string | null;
  impersonate: (userId: string) => void;
  stopImpersonating: () => User | null;
}


export const useUser = (): PatchedUserContextType => {
  const context = useContext(UserContext as React.Context<PatchedUserContextType | undefined>);
  if (!context) {
    throw new Error('useUser must be used within a UserProvider');
  }
  return context;
};