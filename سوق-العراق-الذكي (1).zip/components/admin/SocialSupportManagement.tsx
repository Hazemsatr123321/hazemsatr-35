import React, { useMemo } from 'react';
import { useAdmin } from '../../contexts/AdminContext';
import { Button } from '../common/Button';
import { StarIcon } from '../icons/StarIcon';
import { HandHeartIcon } from '../icons/HandHeartIcon';

export const SocialSupportManagement: React.FC = () => {
    const { ads, users, featureAdForFree } = useAdmin();

    const smallProjectAds = useMemo(() => {
        return ads.filter(ad => {
            const user = users.find(u => u.id === ad.userId);
            return user?.role === 'retailer' && ad.status === 'approved';
        });
    }, [ads, users]);
    
    const charitableAds = useMemo(() => {
        return ads.filter(ad => ad.isCharitable && ad.status === 'approved');
    }, [ads]);

    const unfeaturedSmallProjects = smallProjectAds.filter(ad => !ad.featured);

    const featuredThisWeekCount = useMemo(() => {
        const oneWeekAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
        return smallProjectAds.filter(ad => 
            ad.featured && ad.featuredUntil && new Date(ad.featuredUntil) > oneWeekAgo
        ).length;
    }, [smallProjectAds]);

    const handleFeature = (adId: string) => {
        if (featuredThisWeekCount >= 10) {
            alert('لقد وصلت إلى الحد الأقصى (10) من الإعلانات المميزة لهذا الأسبوع.');
            return;
        }
        if (window.confirm('هل أنت متأكد من تمييز هذا الإعلان مجاناً لمدة أسبوع؟')) {
            featureAdForFree(adId);
        }
    };

    return (
        <div>
            <h2 className="text-3xl font-bold mb-6 text-brand-text flex items-center gap-3">
                <HandHeartIcon className="w-8 h-8"/>
                إدارة الدعم الاجتماعي
            </h2>

            {/* Small Projects Management */}
            <div className="bg-brand-secondary p-6 rounded-lg mb-8">
                <div className="flex justify-between items-center mb-4">
                    <h3 className="text-xl font-semibold text-brand-accent">دعم المشاريع الصغيرة</h3>
                    <div className="bg-brand-primary/50 text-brand-accent font-bold px-4 py-2 rounded-lg">
                        {featuredThisWeekCount} / 10 إعلانات مميزة هذا الأسبوع
                    </div>
                </div>
                <p className="text-brand-text-secondary mb-4">
                    اختر الإعلانات من القائمة أدناه لتمييزها مجاناً لمدة أسبوع.
                </p>
                <div className="max-h-96 overflow-y-auto space-y-2">
                    {unfeaturedSmallProjects.length > 0 ? unfeaturedSmallProjects.map(ad => {
                        const user = users.find(u => u.id === ad.userId);
                        return (
                            <div key={ad.id} className="bg-brand-primary/50 p-3 rounded-lg flex items-center justify-between">
                                <div className="flex items-center gap-3">
                                    <img src={ad.images[0]} alt={ad.title} className="w-16 h-12 object-cover rounded"/>
                                    <div>
                                        <p className="font-bold text-white">{ad.title}</p>
                                        <p className="text-xs text-gray-400">بواسطة: {user?.name}</p>
                                    </div>
                                </div>
                                <Button onClick={() => handleFeature(ad.id)} className="!py-1.5 !px-3 flex items-center gap-1.5" disabled={featuredThisWeekCount >= 10}>
                                    <StarIcon className="w-4 h-4"/>
                                    تمييز لأسبوع
                                </Button>
                            </div>
                        );
                    }) : (
                        <p className="text-center text-gray-400 py-8">لا توجد إعلانات مشاريع صغيرة غير مميزة حالياً.</p>
                    )}
                </div>
            </div>
            
             {/* Charitable Ads Overview */}
            <div className="bg-brand-secondary p-6 rounded-lg">
                 <h3 className="text-xl font-semibold text-brand-accent mb-4">إعلانات مبادرة دعم الفقراء ({charitableAds.length})</h3>
                 <div className="max-h-96 overflow-y-auto space-y-2">
                    {charitableAds.length > 0 ? charitableAds.map(ad => {
                         const user = users.find(u => u.id === ad.userId);
                        return (
                             <div key={ad.id} className="bg-brand-primary/50 p-3 rounded-lg flex items-center justify-between">
                                <div className="flex items-center gap-3">
                                    <img src={ad.images[0]} alt={ad.title} className="w-16 h-12 object-cover rounded"/>
                                    <div>
                                        <p className="font-bold text-white">{ad.title}</p>
                                        <p className="text-xs text-gray-400">بواسطة: {user?.name}</p>
                                    </div>
                                </div>
                            </div>
                        )
                    }) : (
                         <p className="text-center text-gray-400 py-8">لا توجد إعلانات مشاركة في المبادرة الخيرية حالياً.</p>
                    )}
                 </div>
            </div>
        </div>
    );
};
