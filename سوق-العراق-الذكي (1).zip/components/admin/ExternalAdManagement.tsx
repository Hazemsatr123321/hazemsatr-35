
import React, { useState } from 'react';
import { useAdmin } from '../../contexts/AdminContext';
import { Input } from '../common/Input';
import { Button } from '../common/Button';
import type { ExternalAd } from '../../types';

export const ExternalAdManagement: React.FC = () => {
    const { externalAds, addExternalAd, updateExternalAd } = useAdmin();
    const [newAd, setNewAd] = useState({ companyName: '', imageUrl: '', targetUrl: '', isActive: true });

    const handleAddAd = (e: React.FormEvent) => {
        e.preventDefault();
        if(newAd.companyName && newAd.imageUrl && newAd.targetUrl) {
            addExternalAd(newAd);
            setNewAd({ companyName: '', imageUrl: '', targetUrl: '', isActive: true });
        }
    };

    return (
        <div>
            <h2 className="text-2xl font-bold mb-6">إدارة إعلانات الشركات</h2>
            
            <div className="bg-brand-secondary p-6 rounded-lg mb-8">
                <h3 className="text-xl font-semibold mb-4">إضافة إعلان جديد</h3>
                <form onSubmit={handleAddAd} className="grid grid-cols-1 md:grid-cols-2 gap-4 items-end">
                    <Input label="اسم الشركة" value={newAd.companyName} onChange={e => setNewAd({...newAd, companyName: e.target.value})} required />
                    <Input label="رابط الصورة" value={newAd.imageUrl} onChange={e => setNewAd({...newAd, imageUrl: e.target.value})} required />
                    <Input label="رابط الوجهة (URL)" value={newAd.targetUrl} onChange={e => setNewAd({...newAd, targetUrl: e.target.value})} required />
                    <Button type="submit" className="md:col-span-2">إضافة الإعلان</Button>
                </form>
            </div>

            <div className="space-y-4">
                {externalAds.map(ad => (
                    <div key={ad.id} className="bg-brand-secondary p-4 rounded-lg flex items-center justify-between">
                        <div className="flex items-center gap-4">
                            <img src={ad.imageUrl} alt={ad.companyName} className="w-24 h-12 object-contain rounded bg-white"/>
                            <div>
                                <p className="font-bold text-brand-text">{ad.companyName}</p>
                                <a href={ad.targetUrl} target="_blank" rel="noopener noreferrer" className="text-xs text-brand-accent hover:underline">{ad.targetUrl}</a>
                            </div>
                        </div>
                        <div className="flex items-center gap-4">
                             <span className={`px-2 py-1 rounded-full text-xs font-semibold ${ad.isActive ? 'bg-green-500/20 text-green-400' : 'bg-red-500/20 text-red-400'}`}>
                                {ad.isActive ? 'مفعل' : 'معطل'}
                            </span>
                            <button onClick={() => updateExternalAd({...ad, isActive: !ad.isActive})} className="text-sm font-medium text-blue-400 hover:text-blue-300">
                                {ad.isActive ? 'تعطيل' : 'تفعيل'}
                            </button>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
};