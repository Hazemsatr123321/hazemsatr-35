import React from 'react';

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  children: React.ReactNode;
  variant?: 'primary' | 'secondary' | 'outline';
  className?: string;
}

const triggerHapticFeedback = () => {
  if (navigator.vibrate) {
    navigator.vibrate(10); // A short vibration for a tap-like feedback
  }
};

export const Button: React.FC<ButtonProps> = ({ children, variant = 'primary', className = '', onClick, ...props }) => {
  const baseStyle = 'px-6 py-2.5 rounded-lg font-bold text-center transition-transform transform active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed';
  
  const variantStyles = {
    primary: 'bg-brand-accent text-brand-primary hover:bg-brand-accent-hover',
    secondary: 'bg-brand-secondary text-brand-text hover:bg-gray-600',
    outline: 'bg-transparent border-2 border-brand-accent text-brand-accent hover:bg-brand-accent hover:text-brand-primary',
  };

  const handleClick = (e: React.MouseEvent<HTMLButtonElement>) => {
    triggerHapticFeedback();
    if (onClick) {
      onClick(e);
    }
  };

  return (
    <button className={`${baseStyle} ${variantStyles[variant]} ${className}`} onClick={handleClick} {...props}>
      {children}
    </button>
  );
};
