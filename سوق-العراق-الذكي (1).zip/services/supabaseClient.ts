import { createClient } from '@supabase/supabase-js';

// استبدل هذه القيم بالقيم الخاصة بمشروعك في Supabase
const supabaseUrl = 'https://ntevuuijlmpxawryulao.supabase.co';
const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im50ZXZ1dWlqbG1weGF3cnl1bGFvIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTQ2NTY2NDEsImV4cCI6MjA3MDIzMjY0MX0.95qpMOwWBB8eYMG0N3UrzFtpH4OdIDdiC1z2KSuXAvU';

export const supabase = createClient(supabaseUrl, supabaseAnonKey);
